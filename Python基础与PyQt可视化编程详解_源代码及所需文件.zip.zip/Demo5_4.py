def double(x):   #Demo5_4.py
    print("形参修改前的值{}和地址{}".format(x,id(x)))
    if type(x) != type([1,2]):
        x = x*2      #改变形参的值
    elif type(x) == type([1,2]):
        y= list()    #新列表
        y.extend(x)  #形参的值移到新列表中
        n = len(y)
        for i in range(n):
            y[i] = y[i]*2  #改变新列表的值
        print("临时列表的值{}和地址{}".format(y,id(y)))
    print("形参修改后的值{}和地址{}".format(x,id(x)))

listNum = [1,2,3]
print("函数调用前的实参值{}和地址{}".format(listNum,id(listNum)))
double(listNum)   #调用函数，地址传递
print("函数调用后的实参值{}和地址{}".format(listNum,id(listNum)))
