class student(object): #学生类  #Demo6_12.py
    def __init__(self,number="0",name="",chn="0",math="0",phy="",che="0"):
        self._number = int(number)
        self._name = name
        self._chn = int(chn)
        self._math = int(math)
        self._phy = int(phy)
        self._che = int(che)
        self.__total = self._chn+self._math+self._phy+self._che  #计算总成绩
        self.__ave = self.__total/4  # 计算平均成绩
    def getTotal(self):  #输出总成绩
        return self.__total
    def getAve(self):   #输出平均成绩
        return self.__ave
def readData(fileName,coding):  #读取文件中的数据，输出数据列表
    string = list()  #空列表
    try:
        fp = open(fileName,'r',encoding=coding)
        while True:
            line = fp.readline()  #读取行数据
            if len(line)>0:
                line = line.strip()  # 去除行尾的\n
                if len(line)>0:
                    string.append(line) #把数据放到string列表中
            else:
                break  #读到最后终止
    except:
        print("打开或读取文件有误！")
    else:
        n = len(string)
        for i in range(n):
            string[i] = string[i].split() #将string中的元素分解成列表
        return string
    finally:
        fp.close()
if __name__=="__main__":
    ss = readData("d:\\python\\student.txt","UTF-8")
    stDict = dict() #存放学生实例对象的字典
    n =len(ss)
    for i in range(1,n):  #以学号为键，以学生对象为键的值
        num = int(ss[i][0])
        stDict[num]= student(ss[i][0],ss[i][1],ss[i][2],ss[i][3],ss[i][4],ss[i][5])
    stNumber = list(stDict.keys()) #学号列表
    stNumber.sort()  #学号列表
    fp = open("d:\\python\\student_score.txt","w") #打开新文件，用于写入数据
    fp.write("   学号     姓名    语文  数学  物理  化学   总分   平均分\n") #写表头
    template="{:=8d}{:>6s}{:=6d}{:=6d}{:=6d}{:=6d}{:=8d}{:=8.1f}\n" #模板
    for i in stNumber:
        fp.write(template.format(stDict[i]._number,stDict[i]._name,stDict[i]._chn,
                 stDict[i]._math,stDict[i]._phy,stDict[i]._che,
                 stDict[i].getTotal(),stDict[i].getAve()))  # 用模板往文件中写字符串
    fp.close()
