from openpyxl import load_workbook  #Demo6_25.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
ac=wsheet.active_cell  #活动单元格
print(wsheet[ac].value)
print(wsheet.max_row,wsheet.max_column)
print(wsheet.min_row,wsheet.min_column)
wsheet.move_range("A1:F6",rows=6,cols=3)  #移动单元格
