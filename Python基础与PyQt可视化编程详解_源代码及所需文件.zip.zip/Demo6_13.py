#Demo6_13.py
string=["草长莺飞二月天，","拂堤杨柳醉春烟。","儿童散学归来早，","忙趁东风放纸鸢。"]
for i in range(len(string)):
    string[i] = string[i]+"\n"
fp = open("d:\\python\\村居.txt","w")
fp.writelines(string)
fp.close()
