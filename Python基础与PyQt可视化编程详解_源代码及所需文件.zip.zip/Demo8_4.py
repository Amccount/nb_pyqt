from PyQt5.QtCore import QSize,QSizeF,Qt   #Demo8_4.py

s1=QSize(5,6)
s2=QSize(8,10)
s3=s2-s1
print("s3:",s3.width(), s3.height())
s4= s1*3
print("s4:",s4.width(), s4.height())

s1 = QSize(5, 6)
s1.scale(10,20,Qt.IgnoreAspectRatio)
print("IgnoreAspectRatio:",s1.width(), s1.height())
s1 = QSize(5, 6)
s1.scale(10,20,Qt.KeepAspectRatio)
print("KeepAspectRatio:",s1.width(), s1.height())
s1 = QSize(5, 6)
s1.scale(10,20,Qt.KeepAspectRatioByExpanding)
print("KeepAspectRatioByExpanding:",s1.width(), s1.height())
#运行结果
#s3: 3 4
#s4: 15 18
#IgnoreAspectRatio: 10 20
#KeepAspectRatio: 10 12
#KeepAspectRatioByExpanding: 16 20
