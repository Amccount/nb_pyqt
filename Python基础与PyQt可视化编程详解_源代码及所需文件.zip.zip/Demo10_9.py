import sys  #Demo10_9.py
from PyQt5.QtWidgets import QApplication,QWidget,QPushButton,QFrame,QHBoxLayout
from PyQt5.QtGui import QDrag
from PyQt5.QtCore import QPoint,QMimeData,Qt,QEvent,QCoreApplication

class myEvent(QEvent):   #自定义事件
    myID = QEvent.registerEventType(20000)  #注册ID号
    def __init__(self,position,object_name=None):
        QEvent.__init__(self,myEvent.myID)
        self.__pos = position   #位置属性，可对数据做其他处理
        self.__name = object_name  #名称属性
    def get_pos(self):  #事件的方法
        return self.__pos
    def get_name(self):   #事件的方法
        return self.__name

class myPushButton(QPushButton):
    def __init__(self,name=None,parent=None):
        super().__init__(parent)
        self.setText(name)
    def mousePressEvent(self, event):  #按键事件
        if event.button() == Qt.LeftButton:
            drag = QDrag(self)
            drag.setHotSpot(event.pos()-self.rect().topLeft())
            mime = QMimeData()
            drag.setMimeData(mime)
            drag.exec()
    def moveEvent(self, event):
        self.__customEvent = myEvent(event.pos(), self.objectName())  #自定义事件的实例化
        QCoreApplication.sendEvent(self.window(), self.__customEvent)  #发送事件
class myFrame(QFrame):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setFrameShape(QFrame.Box)
    def dragEnterEvent(self,event):
        self.child = self.childAt(event.pos())  #获取指定位置的控件
        if self.child:
            event.accept()
        else:
            event.ignore()
    def dragMoveEvent(self,event):
        if self.child:
            self.__center = QPoint(int(self.child.width() / 2), int(self.child.height() / 2))
            self.child.move(event.pos() - self.__center)
class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi()
        self.resize(600,400)
        self.setAcceptDrops(True)
    def setupUi(self):
        self.frame_1 = myFrame(self)
        self.frame_2 = myFrame(self)
        H = QHBoxLayout(self)
        H.addWidget(self.frame_1)
        H.addWidget(self.frame_2)
        self.btn1 = myPushButton("PushButton 1",self.frame_1)  #定义第1个按钮
        self.btn1.setObjectName("button1")  #按钮的名称
        self.btn2 = myPushButton("PushButton 2",self.frame_1)  #定义第2个按钮
        self.btn2.setObjectName("button2")  #按钮的名称
        self.btn3 = myPushButton("PushButton 3", self.frame_2)  # 定义第3个按钮
        self.btn3.setObjectName("button3")  #按钮的名称
        self.btn4 = myPushButton("PushButton 4", self.frame_2)  # 定义第4个按钮
        self.btn4.setObjectName("button4")  #按钮的名称
    def customEvent(self,event) :  #自定义事件的处理函数
        if event.type() == myEvent.myID:
            if event.get_name() == "button1":
                self.btn3.move(event.get_pos())
            if event.get_name() == "button2":
                self.btn4.move(event.get_pos())
            if event.get_name() == "button3":
                self.btn1.move(event.get_pos())
            if event.get_name() == "button4":
                self.btn2.move(event.get_pos())
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
