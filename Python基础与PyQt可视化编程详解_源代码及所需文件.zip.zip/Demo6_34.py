from openpyxl import  Workbook  #Demo6_34.py
from openpyxl.chart import  Reference,PieChart,PieChart3D,DoughnutChart
data = [["季度","销售额(万元)"],
        ["第1季度",20.2],["第2季度",30.6],
        ["第3季度",60.2],["第4季度",104.2] ]
wbook = Workbook()
wsheet = wbook.active
for item in data:
    wsheet.append(item)
pie = PieChart()
pie3D = PieChart3D()
doughnut = DoughnutChart()

pie.title = pie3D.title = doughnut.title = "季度销售额"

label = Reference(wsheet,min_col=1,min_row=2,max_row=5)
data = Reference(wsheet,min_col=2,min_row=1,max_row=5)

pie.add_data(data,titles_from_data=True)
pie3D.add_data(data,titles_from_data=True)
doughnut.add_data(data,titles_from_data=True)

pie.set_categories(label)
pie3D.set_categories(label)
doughnut.set_categories(label)

pie.width = pie3D.width = doughnut.width = 10
pie.height = pie3D.height = doughnut.height = 8

wsheet.add_chart(pie,"A10")
wsheet.add_chart(pie3D,"H10")
wsheet.add_chart(doughnut,"A20")
wbook.save("d:\\python\\pie_doughnut.xlsx")
