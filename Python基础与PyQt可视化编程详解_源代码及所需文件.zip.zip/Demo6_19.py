from openpyxl import load_workbook   #Demo6_19.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet1 = wbook['学生成绩']
wsheet2 = wbook.get_sheet_by_name('Sheet')
wbook.copy_worksheet(wsheet1)  #复制工作表格实例
print(wbook.sheetnames)
wbook.remove(wsheet1)  #删除工作表格实例
wbook.remove_sheet(wsheet2)  #删除工作表格实例
print(wbook.sheetnames)
#运行结果
#['学生成绩', 'Sheet', '学生成绩 Copy']
#['学生成绩 Copy']
