import sys   #Demo5_37.py
print(sys.argv)
n = len(sys.argv)
if n > 1:
    for i in range(1,n):
        print("你输入的第{}个参数是{}".format(i,sys.argv[i]))
#运行结果：
#['D:/test.py']
