import sys   #Demo5_38.py

x = input("请输入第1个数：")
y = input("请输入第2个数：")
x = float(x)
y = float(y)
if y == 0:
    print("你输入的第2个数是0，程序发生致命错误而退出！")
    sys.exit(1)
print("这两个数的商是：", x/y)
#运行结果：
#请输入第1个整数：3
#请输入第2个整数：0
#你输入的第2个数是0，程序发生致命错误而退出！
