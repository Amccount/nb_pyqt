from openpyxl import load_workbook   #Demo6_17.py
wbook = load_workbook("d:\\python\\student.xlsx")

wsheet1 = wbook['学生成绩']
wsheet2 = wbook.get_sheet_by_name('Sheet')
print(wsheet1.title,wsheet2.title)
for sheet in wbook:  #遍历工作表格
    print(sheet.title)
