class person:   #Demo5_25.py
    def __init__(self,name=None):
        self.name = name
    def setName(self,name):
        self.name = name
class student(person):
    def __init__(self,number = None,score = None):
        super().__init__()   #调用父类的初始化函数
        self.number = number
        self.score = score
    def setNumber(self,number):
        self.number = number
    def setScore(self,score):
        self.score = score

liming = student()       #student的实例中有父类和子类的属性和方法
liming.setName("李明")   #调用父类的setName()方法
liming.setNumber(20201)  #调用子类的setNumber()方法
liming.setScore(98)      #调用子类的setScore()方面
print("姓名：{} 学号：{} 成绩：{}".format(liming.name,liming.number,liming.score))

#运行结果
#姓名：李明 学号：20201 成绩：98
