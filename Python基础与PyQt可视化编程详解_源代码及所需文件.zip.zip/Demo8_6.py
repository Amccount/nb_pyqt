import sys   #Demo8_6.py
from PyQt5.QtWidgets import QApplication,QWidget,QPushButton
from PyQt5.QtGui import QPixmap,QIcon

class setIcon(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        pix =QPixmap()
        pix.load("d:\\python\\pic.png")
        icon =QIcon(pix)
        self.setWindowIcon(icon)   #设置窗口图标
        btn = QPushButton(self)
        btn.setIcon(icon)  #设置按钮图标

if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = setIcon()
    window.show()
    n= app.exec()
    sys.exit(n)
