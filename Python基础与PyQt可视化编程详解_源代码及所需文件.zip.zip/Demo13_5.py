import sys,math,struct   #Demo13_5.py
from PyQt5.QtWidgets import QApplication,QMainWindow,QPlainTextEdit,QFileDialog
from PyQt5.QtCore import QFile,QDataStream

class myWindow(QMainWindow):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(800,600)
        self.setupUI()  #界面
        self.fileName = "d:\\sin_cos.raw"
    def setupUI(self):  #界面建立
        self.plainText = QPlainTextEdit()
        self.setCentralWidget(self.plainText)
        self.status=self.statusBar()
        self.menubar = self.menuBar()  # 菜单栏
        self.file=self.menubar.addMenu('文件')  #文件菜单
        action_binCreate=self.file.addAction('生成文件')  #动作
        action_binCreate.triggered.connect(self.rawCreate_triggered)  #动作与槽的连接
        action_binOpen = self.file.addAction('打开文件')  #动作
        action_binOpen.triggered.connect(self.rawOpen_triggered)  #动作与槽的连接
        self.file.addSeparator()
        action_close = self.file.addAction('关闭')
        action_close.triggered.connect(self.close)
    def rawCreate_triggered(self):
        file=QFile(self.fileName)
        try:
            if file.open(QFile.WriteOnly | QFile.Truncate): #打开文件
                writer=QDataStream(file)  #创建数据流
                writer.setVersion(QDataStream.Qt_5_14)  #设置版本
                writer.setByteOrder(QDataStream.BigEndian)  #设置字节序
                byt= bytes("version:Qt_5_14", encoding="UTF-8")
                writer.writeBytes(byt)  #写入字节串
                byt = bytes("x(度)", encoding="UTF-8")
                writer.writeBytes(byt)  #写入字节串
                byt = bytes("sin(x)", encoding="UTF-8")
                writer.writeBytes(byt)  #写入字节串
                byt = bytes("cos(x)", encoding="UTF-8")
                writer.writeBytes(byt)  #写入字节串
                byt = bytes("sin(x)+cos(x)", encoding="UTF-8")
                writer.writeBytes(byt)  #写入字节串
                for i in range(360):
                    r=i/180*math.pi
                    sin=math.sin(r)  #sin
                    cos=math.cos(r)   #cos
                    sin_cos=math.sin(r)+math.cos(r)  #sin+cos
                    byt=struct.pack(">Hfff",i,sin,cos,sin_cos)  #数值转换成字节串
                    writer.writeRawData(byt)  #写入原生数据
        except:
            self.status.showMessage("写入文件失败！")
        finally:
            self.status.showMessage("写入文件成功！")
        file.close()
    def rawOpen_triggered(self):
        (fileName, fil) = QFileDialog.getOpenFileName(self, caption="打开原生文件",
                     directory="d:\\",filter="原生文件(*.raw);;所有文件(*.*)")
        file = QFile(fileName)
        template="{:^10}{:^20.13}{:^20.13}{:^20.13}"
        try:
            if file.open(QFile.ReadOnly):  #打开文件
                reader = QDataStream(file)
                reader.setVersion(QDataStream.Qt_5_14)
                reader.setByteOrder(QDataStream.BigEndian)
                byt=reader.readBytes()
                if byt.decode(encoding="UTF-8")=="version:Qt_5_14":
                    self.plainText.clear()
                    str1 = reader.readBytes().decode("UTF-8")  #读取字符串并解码
                    str2 = reader.readBytes().decode("UTF-8")  #读取字符串并解码
                    str3 = reader.readBytes().decode("UTF-8")  #读取字符串并解码
                    str4 = reader.readBytes().decode("UTF-8")  #读取字符串并解码
                    string=template.format(str1,str2,str3,str4)
                    self.plainText.appendPlainText(string)
                    while not reader.atEnd():
                        byt = reader.readRawData(struct.calcsize(">Hfff")) #读取原生数据
                        number=struct.unpack(">Hfff",byt)  #对原生数据解码
                        string=template.format(number[0],number[1],number[2],number[3])
                        self.plainText.appendPlainText(string)
        except:
            self.status.showMessage("打开文件失败！")
        finally:
            self.status.showMessage("打开文件成功！")
        file.close()
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
