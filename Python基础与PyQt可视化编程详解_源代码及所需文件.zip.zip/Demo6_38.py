from openpyxl import Workbook  #Demo6_38.py
from openpyxl.chart import Reference,Series,BubbleChart
wbook = Workbook()
wsheet = wbook.active
score1 = [['日期', '一班工作量', '成绩'],
         [1, 90.2, 96], [3, 95, 89.8],
         [5, 89, 93.2], [7, 94.6, 92],
         [9, 89.8, 88]]
score2 = [['日期', '二班工作量', '成绩'],
         [2, 93.3, 94], [4, 91, 82.4],
         [6, 85, 96.2], [8, 84.6, 97.4],
         [10, 91.8, 86]]
for item in score1:
    wsheet.append(item)
for item in score2:
    wsheet.append(item)
bubble = BubbleChart()
bubble.x_axis.title = "日期"
bubble.y_axis.title = "工作量"

xLabel = Reference(wsheet,min_col=1,min_row=2,max_row=6)  #设置x轴坐标数据
yData = Reference(wsheet,min_col=2,min_row=2,max_row=6)  #设置y轴坐标数据
zData = Reference(wsheet,min_col=3,min_row=2,max_row=6)  #设置球的尺寸数据
ser = Series(yData,xvalues=xLabel,zvalues=zData,title="一班业绩")
bubble.append(ser)

xLabel = Reference(wsheet,min_col=1,min_row=8,max_row=12)  #设置x轴坐标数据
yData = Reference(wsheet,min_col=2,min_row=8,max_row=12)  #设置y轴坐标数据
zData = Reference(wsheet,min_col=3,min_row=8,max_row=12)  #设置球的尺寸数据
ser = Series(yData,xvalues=xLabel,zvalues=zData,title="二班业绩")
bubble.append(ser)

bubble.width= 13   #设置高度
bubble.height= 8  #设置宽度

wsheet.add_chart(bubble,"A15")   #将图标添加进工作表格中
wbook.save(filename="d:\\python\\bubble.xlsx")
