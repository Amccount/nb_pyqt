import sys   #Demo12_14.py
from PyQt5.QtWidgets import QApplication,QWidget,QVBoxLayout,QGraphicsProxyWidget,\
 QGraphicsScene,QGraphicsView,QPushButton,QGraphicsWidget,QGraphicsLinearLayout,QLabel
from PyQt5.QtCore import Qt

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        
        view = QGraphicsView()  # 视图控件
        scene = QGraphicsScene()  # 场景
        view.setScene(scene)  # 视图中设置场景
        v = QVBoxLayout(self)  # 布局
        v.addWidget(view)

        widget=QGraphicsWidget(None,Qt.Window)
        scene.addItem(widget)
        linear = QGraphicsLinearLayout(widget)  #线性布局

        label1=QLabel("aaa")
        label2=QLabel("bbb")
        button1=QPushButton("ccc")
        button2=QPushButton("ddd")
        p1=QGraphicsProxyWidget()  #代理
        p1.setWidget(label1)
        p2 = QGraphicsProxyWidget()  #代理
        p2.setWidget(label2)
        p3 = QGraphicsProxyWidget()  #代理
        p3.setWidget(button1)
        p4 = QGraphicsProxyWidget()  #代理
        p4.setWidget(button2)
        linear.addItem(p1)
        linear.addItem(p2)
        linear.addItem(p3)
        linear.addItem(p4)
        linear.setSpacing(20)
        linear.setStretchFactor(p3,1)
        linear.setStretchFactor(p4,2)
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
