def double(x):   #Demo5_3.py
    print("形参修改前的值{}和地址{}".format(x,id(x)))
    if type(x) != type([1,2]):
        x = x*2      #改变形参的值
    elif type(x) == type([1,2]):
        n = len(x)
        for i in range(n):
            x[i] = x[i]*2  #改变形参的值
    print("形参修改后的值{}和地址{}".format(x,id(x)))

n = 100
print("函数调用前的实参值{}和地址{}".format(n,id(n)))
double(n)        #调用函数，值传递
print("函数调用后的实参值{}和地址{}".format(n,id(n)))

print("*"*50)

string = "Hello.Nice to meet you!"
print("函数调用前的实参值{}和地址{}".format(string,id(string)))
double(string)   #调用函数，值传递
print("函数调用后的实参值{}和地址{}".format(string,id(string)))

print("*"*50)

listNum = [1,2,3]
print("函数调用前的实参值{}和地址{}".format(listNum,id(listNum)))
double(listNum)   #调用函数，地址传递
print("函数调用后的实参值{}和地址{}".format(listNum,id(listNum)))
