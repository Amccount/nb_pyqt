def var():   #Demo5_11.py
    mess = "我是局部变量"
    print(mess,id(mess))
# 下面是主程序
mess = "我是全局变量"
var()
print(mess,id(mess))
#运行结果
#我是局部变量 2183036115072
#我是全局变量 2183036113392
