ss=""  #Demo6_9.py
try:
    fp = open("D:\\Python\\study.txt",'r',encoding='UTF-8')
    for i in range(1,11):
        print(fp.tell())
        ss = ss+fp.read(20)   #读取文件内容
        fp.seek(40*i)
except:
    print("打开或读取文件有误！")
finally:
    fp.close()
    print(ss)
