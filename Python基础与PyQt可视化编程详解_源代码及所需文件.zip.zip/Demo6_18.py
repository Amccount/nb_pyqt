from openpyxl import load_workbook   #Demo6_18.py
wbook = load_workbook("d:\\python\\student.xlsx")
for name in wbook.sheetnames:  #遍历所有工作表格对象的名称
    print(name)
wsheet1 = wbook['学生成绩']  #根据名称获取工作表格对象
wsheet2 = wbook.get_sheet_by_name('Sheet')  #根据名称获取工作表格对象
print(wsheet1.title,wsheet2.title)  #获取工作表格实例的名称

a = wbook.index(wsheet1)  #获取工作表格实例的序列号
b = wbook.get_index(wsheet2)  #获取工作表格实例的序列号
print(a,b)
#运行结果
#学生成绩
#Sheet
#学生成绩 Sheet
#0 1
