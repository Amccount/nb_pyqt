import sys  #Demo7_8.py
from PyQt5.QtWidgets import QApplication, QWidget

import myUi  #导入myUi.py文件

class QmyWidget(QWidget): #创建QmyWindget类，父类是QWidget
    def __init__(self,parent = None):
        super().__init__(parent)  #初始化父类QWidget，这时self是QWidget的窗口对象
        ui = myUi.QmyUi()  #实例化myUi.py文件中的QmyUi类
        ui.setupUi(self)  #调用QmyUi类的函数setupUi()，并以self为实参传递给形参window
        ui.button.setText("Close")  # 重新设置按钮的显示文字
        ui.button.clicked.connect(self.close)  # 窗口上的按钮事件与窗口事件关联

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = QmyWidget() #用QmyWidget()类实例化对象myWindow，myWindow是窗口
    myWindow.show()
    n = app.exec()
    sys.exit(n)
