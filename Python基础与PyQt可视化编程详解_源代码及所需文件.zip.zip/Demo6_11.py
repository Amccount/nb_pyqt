try:  #Demo6_11.py
    fp = open("D:\\Python\\student.txt",'r',encoding='UTF-8')
    lines = fp.readlines()  #读取所有行数据
except:
    print("打开或读取文件有误！")
else:
    fp.close()
finally:
    for i in lines:
        print(i.strip())
#运行结果
#学号      姓名   语文    数学    物理    化学
#202003   没头脑   89     88      93      87
#202002   不高兴   80     71      88      98
#202004   倒霉蛋   95     92      88      94
#202001   鸭梨头   93     84      84      77
#202005   墙头草   93     86      73      86
