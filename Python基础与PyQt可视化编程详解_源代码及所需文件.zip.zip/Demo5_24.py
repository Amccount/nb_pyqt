class student(object):  # Demo5_24.py
    def __init__(self, name=None, score=None):
        self.__name = name  # 私有属性
        self.__score = score  # 私有属性

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, name):
        self.__name = name

    @property
    def score(self):
        return self.__score

    @score.setter
    def score(self, score):
        self.__score = score

    @score.deleter
    def score(self):
        del self.__score


liming = student()
liming.name = "李明"  # 调用输入函数
liming.score = 98  # 调用输入函数
print("{}的成绩是{}".format(liming.name, liming.score))  # 调用输出函数
del liming.score  # 删除私有属性
