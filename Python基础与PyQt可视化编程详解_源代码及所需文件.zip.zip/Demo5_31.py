# run.py   #Demo5_31.py
import student

s1 = student.st(name="李明",number=20201,score=89) #调用student中的类st
s2 = student.st(name="高新",number=20202,score=93) #调用student中的类st
s3 = student.st(name="李丽",number=20203,score=91) #调用student中的类st

tot = student.total(s1.score,s2.score,s3.score) #调用student中的函数total()
avg = student.average(s1.score,s2.score,s3.score) #调用student中的函数average()

print("三个学生的总成绩{}，平均成绩{}".format(tot,avg))
#运行结果
#三个学生的总成绩273，平均成绩91.0
