def person(name="New Person", **feature):  # name是必须输入，feature是字典 #Demo5_8.py
    person_name = name  # 定义姓名
    height = None  # 定义身高
    weight = None  # 定义体重
    sex = None  # 定义性别
    age = None  # 定义年龄
    job = None  # 定义职业

    if "height" in feature: height = feature["height"]  # 获取身高
    if "weight" in feature: weight = feature["weight"]  # 获取体重
    if "sex" in feature: sex = feature["sex"]  # 获取性别
    if "age" in feature: age = feature["age"]  # 获取年龄
    if "job" in feature: job = feature["job"]  # 获取职业

    print("{}的身高{},体重{},性别{},年龄{},工作{}".format(name, height, weight, sex, age, job))


person("Robot", height=177, sex=True, weight=78)
person("Robot", height=177, sex=True, weight=78, job="writer")
# 运行结果
# Robot的身高177,体重78,性别True,年龄38,工作None
# Robot的身高177,体重78,性别True,年龄38,工作writer
