def total(n):  #Demo6_6.py
    tt = 0
    for i in range(1,n+1):
        tt = tt+i
    return tt
if __name__ == "__main__":
    n = input("请输入正整数：")
    try:
        n = int(n)
        s = total(n)
        print("从1到{}的和是{}".format(n,s))
    except:
        import sys
        errorMessage = sys.exc_info()
        print(errorMessage)
        n = input("您的输入是{},输入不是正整数，请重新输入：".format(n))
        try:
            n = int(n)
            s = total(n)
            print("从1到{}的和是{}".format(n,s))
        except:
            n = input("您的输入是{},输入不是正整数，请再次输入：".format(n))
            try:
                n = int(n)
                s = total(n)
                print("从1到{}的和是{}".format(n,s))
            except:
                print("您已经输错3次，程序结束。")
#运行结果：
#请输入正整数：shi
#(<class 'ValueError'>, ValueError("invalid literal for int() with base 10: 'shi'"),
#<traceback object at 0x0000022FE908B540>)
#您的输入是shi,输入不是正整数，请重新输入：ershi
#您的输入是ershi,输入不是正整数，请再次输入：sanshi
#您已经输错3次，程序结束。
