from PyQt5.QtWidgets import QDialog,QPushButton,QLineEdit,QHBoxLayout,QFormLayout
class myDialog(QDialog):     #Demo9_10.py
    def __init__(self,parent=None):
        super().__init__(parent)
        self.dialog_setupUi()
    def dialog_setupUi(self):  # 建立对话框界面
        self.btn_apply = QPushButton("应用")
        self.btn_ok = QPushButton("确定")
        self.btn_cancel = QPushButton("取消")
        h = QHBoxLayout()
        h.addWidget(self.btn_apply)
        h.addWidget(self.btn_ok)
        h.addWidget(self.btn_cancel)
        self.line_name = QLineEdit()
        self.line_number = QLineEdit()
        self.line_chinese = QLineEdit()
        self.line_math = QLineEdit()
        self.line_english = QLineEdit()
        f = QFormLayout(self)
        f.addRow("姓名：", self.line_name)
        f.addRow("学号：", self.line_number)
        f.addRow("语文：", self.line_chinese)
        f.addRow("数学：", self.line_math)
        f.addRow("英语：", self.line_english)
        f.addRow(h)
        self.btn_apply.clicked.connect(self.btn_apply_clicked)  #“应用”按钮与自定义槽函数的连接
        self.btn_ok.clicked.connect(self.btn_ok_clicked)  #“确定”按钮与自定义槽函数的连接
        self.btn_cancel.clicked.connect(self.close)  #“取消”按钮与对话框槽函数的连接
    def btn_apply_clicked(self):  #“应用”按钮单击信号槽函数
        self.postion = self.pos()  #记录单击应用按钮时对话框的位置
        self.done(2)   #发射finished信号
    def btn_ok_clicked(self):  #“确定”按钮单击信号槽函数
        self.done(1)  #发射finished信号
