# my_run.py   #Demo5_35.py
from sub_module import module_test

if __name__ == "__main__":
    print("*"*30)
    module_test()
    print("*"*30)
    print("现在的模块是:",__name__)

#运行结果：
#******************************
#我在sub_module模块中运行
#******************************
#现在的模块是: __main__
