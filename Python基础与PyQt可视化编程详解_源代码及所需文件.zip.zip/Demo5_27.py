class girl(object):   #Demo5_27.py
    def setname(self,name):
        self.name = name
    def setage(self,age):
        self.age = age
    def __getattr__(self,item):   #重写方法，当读取数据时触发
        print("getattr",item)
    def __setattr__(self,key,item):   #重写方法，当设置数据时触发
        print('setattr',key ,item)
    def __delattr__(self,item):   #重写方法，当删除属性时触发
        print('delattr',item)
    def __str__(self):    #重写方法，当用print()输出时触发
        return "这是关于一个女孩的类。"

xiaofang = girl()

xiaofang.setname("小芳")  #设置属性，触发__setattr__
xiaofang.setage(22)   #设置属性，触发__setattr__

name = xiaofang.name  #获取属性，触发__getattr__
age = xiaofang.age  #获取属性，触发__getattr__
del xiaofang.age  #删除属性，触发__delattr__
print(xiaofang)  #打印属性，触发__str__
xiaofang.favorate = 'white'  #给不存在的属性设置值，触发__setattr__
bd = xiaofang.birthday  #读取不存在的属性，触发__getattr__

#运行结果
#setattr name 小芳
#setattr age 22
#getattr name
#getattr age
#delattr age
#这是关于一个女孩的类。
#setattr favorate white
#getattr birthday
