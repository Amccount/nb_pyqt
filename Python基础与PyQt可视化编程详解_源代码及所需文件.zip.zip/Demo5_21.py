import math  # Demo5_21.py

class h:
    factor = 2.0  # 类变量

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.xuan = h.rms(self.x, self.y)  # 通过 类名.函数名() 引用类函数

    @classmethod
    def rms(cls, x, y):  # 第1个形参必须是cls
        return math.sqrt((x ** 2 + y ** 2) / 2) * cls.factor  # 通过 cls.类变量 引用类变量

a = h(3, 4)
print(a.xuan)
print(a.rms(3, 4))  # 通过 实例名.函数名() 引起类函数
print(h.rms(3, 4))  # 通过 类名.函数名() 引用类函数
