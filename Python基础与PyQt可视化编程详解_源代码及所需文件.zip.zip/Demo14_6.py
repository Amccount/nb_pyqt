import sys  #Demo14_6.py
from PyQt5.QtWidgets import QApplication,QPushButton,QHBoxLayout,\
    QWidget,QFileDialog,QLabel,QComboBox
from PyQt5.QtCore import QFileInfo,QUrl
from PyQt5.QtMultimedia import QMultimedia,QAudioEncoderSettings,QAudioRecorder

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi()
    def  setupUi(self):  #界面
        btn_path=QPushButton("设置保存路径和文件名")
        btn_record=QPushButton("录制")
        btn_pause=QPushButton("暂停")
        btn_stop=QPushButton("停止")
        combo_deviceName=QComboBox()  #录音设备名称
        self.combo_sampleRate=QComboBox()  #信号采样率
        self.label=QLabel("已经录制时间：0   毫秒")
        h=QHBoxLayout(self)  #水平布局
        h.addWidget(btn_path)
        h.addWidget(combo_deviceName)
        h.addWidget(self.combo_sampleRate)
        h.addWidget(btn_record)
        h.addWidget(btn_pause)
        h.addWidget(btn_stop)
        h.addWidget(self.label)

        self.audioRecorder=QAudioRecorder(self)
        self.fileName="d:/a.wav"  #保存文件

        devices=self.audioRecorder.audioInputs()
        combo_deviceName.addItems(devices)
        combo_deviceName.setCurrentText(self.audioRecorder.defaultAudioInput())
        rates,ok=self.audioRecorder.supportedAudioSampleRates()
        for i in rates:
            self.combo_sampleRate.addItem(str(i))
        self.combo_sampleRate.setCurrentText(str(i))

        btn_path.clicked.connect(self.btn_path_clicked) #信号与槽
        btn_record.clicked.connect(self.btn_record_clicked)
        btn_pause.clicked.connect(self.audioRecorder.pause)
        btn_stop.clicked.connect(self.audioRecorder.stop)
        self.audioRecorder.durationChanged.connect(self.audioRecorder_durationChanged)
        combo_deviceName.currentTextChanged.connect(self.audioRecorder.setAudioInput)
        self.combo_sampleRate.currentTextChanged.connect(
                   self.combo_sampleRate_currentTextChanged)
    def btn_path_clicked(self):
        file_filter = '所有文件(*.*)'
        formats=self.audioRecorder.supportedContainers()  #获取支持的容器格式
        for format in formats:
            if 'wav' in format:
                file_filter = "{}文件(*.{});;".format('wav', 'wav') + file_filter  #文件过滤器
            if 'raw' in format:
                file_filter = "{}文件(*.{});;".format('raw', 'raw') + file_filter  #文件过滤器
        self.fileName, fil = QFileDialog.getSaveFileName(self, caption="设置声音文件名和类型",
                                                     directory='d:/', filter=file_filter)
        extension=QFileInfo(self.fileName).suffix()  #获取扩展名
        for format in formats:
            if extension in format:
                self.audioRecorder.setContainerFormat(format)  #设置容器格式
                return
    def btn_record_clicked(self):
        if self.audioRecorder.isAvailable():
            url=QUrl.fromLocalFile(self.fileName)
            self.audioRecorder.setOutputLocation(url)  #设置输出文件
            audioSettings=QAudioEncoderSettings()  #创建音频设置
            audioSettings.setQuality(QMultimedia.HighQuality)  #设置质量
            audioSettings.setSampleRate(int(self.combo_sampleRate.currentText())) #设置采样率
            audioCodes=self.audioRecorder.supportedAudioCodecs()
            if len(audioCodes): audioSettings.setCodec(audioCodes[0])
            self.audioRecorder.setAudioSettings(audioSettings)
            self.audioRecorder.record()
    def audioRecorder_durationChanged(self,duration):
        self.label.setText("已经录制时间：{}毫秒".format(duration))
    def combo_sampleRate_currentTextChanged(self,string):
        settings=self.audioRecorder.audioSettings()
        settings.setSampleRate(int(string))
        self.audioRecorder.setAudioSettings(settings)
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
