from openpyxl import Workbook  #Demo6_40.py
from openpyxl.chart import LineChart,BarChart,Reference
from copy import deepcopy
wbook = Workbook()
wsheet = wbook.active
data = [ ['日期','一班','二班'],
         ['星期一',79,91],
         ['星期二',62,69],
         ['星期三',78,87],
         ['星期四',68,95],
         ['星期五',95,75] ]
for i in data:
    wsheet.append(i)
line = LineChart()
bar = BarChart()
line.title = '一班成绩'
bar.title = '二班成绩'
line.x_axis.title=bar.x_axis.title = '日期'
line.y_axis.title=bar.y_axis.title = "成绩"
line.width = bar.width = 12
line.height = bar.height = 6

xlable = Reference(wsheet,min_col = 1,min_row=2,max_row=6)
ydata1 = Reference(wsheet,min_col=2,min_row=1,max_row=6)
ydata2 = Reference(wsheet,min_col=3,min_row=1,max_row=6)

line.add_data(ydata1,titles_from_data=True)
line.set_categories(xlable)
bar.add_data(ydata2,titles_from_data=True)
bar.set_categories(xlable)

wsheet.add_chart(line,'A10')
wsheet.add_chart(bar,'J10')

combine = deepcopy(line)  #复制一个图表
combine += bar #将复制的图表与其他图表合并，只能用“+=”，不能用combine=combiner+bar
combine.title = '成绩比较'
wsheet.add_chart(combine,'A25')

wbook.save("d:\\python\\combine.xlsx")
