def btn_open_clicked(self):  #打开按钮的槽函数  Demo14_2.py
    fileNames,fil=QFileDialog.getOpenFileNames(self,caption="选择影音文件",directory="d:\\",
    filter="影音文件(*.wav *.mp4 *.mp3 *.wma *.avi *.wmv *.rm *.asf);;所有文件(*.*)")
    playlist = QMediaPlaylist(self)  # 创建播放列表
    playlist.setPlaybackMode(QMediaPlaylist.Loop)  # 设置循环播放模式
    if len(fileNames):
        for filename in fileNames:
            url=QUrl.fromLocalFile(filename)  #URL地址
            content=QMediaContent(url)  #播放媒体
            playlist.addMedia(content)  #添加到播放列表
        self.player.setPlaylist(playlist)  #设置播放器的播放列表
