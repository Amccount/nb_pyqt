class hello(object):  # Demo5_19.py
    def __init__(self, string="Hello"):  # 第1个形参是self，形参string的默认值是Hello
        self.greeting = string
        self.output()  # 调用output()函数

    def output(self):  # 定义output()函数，需要self形参
        print(self.greeting)


hi = hello("Nice to meet you!")

# 运行结果
# Nice to meet you!
