import openpyxl    #导入openpyxl包    #Demo6_14.py

data=[  ["学号","姓名","语文","数学","物理","化学"],
        ['202003','没头脑',89,88,93,87],
        ['202002','不高兴',80,71,88,98],
        ['202004','倒霉蛋',95,92,88,94],
        ['202001','鸭梨头',93,84,84,77],
        ['202005','墙头草',93,86,73,86]  ]
stBook = openpyxl.Workbook()   #创建工作簿Workbook对象
stSheet = stBook.create_sheet(title="学生成绩", index = 0)   #创建工作表格Workshee对象
for i in range(len(data)):
    for j in range(len(data[i])):
        stSheet.cell(row=i+1, column=j+1, value=data[i][j])  #往单元格Cell中输入数据
stBook.save("d:\\python\\student.xlsx")
