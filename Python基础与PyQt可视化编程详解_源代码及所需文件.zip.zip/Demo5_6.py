import math   #Demo5_6.py
def z(x,y,k=1.0,c=0.0):   #k的默认值是1.0，c的默认值是0.0
    return k*math.sqrt(x**2+y**2)-c

xuan_1 = z(3,4)       #k和c使用默认值
xuan_2 = z(3,4,c=1)   #k使用默认值
xuan_3 = z(3,4,2)     #c使用默认值
xuan_4 = z(y=6,x=5,k=0.5)    #c使用默认值
print(xuan_1,xuan_2,xuan_3,xuan_4)
