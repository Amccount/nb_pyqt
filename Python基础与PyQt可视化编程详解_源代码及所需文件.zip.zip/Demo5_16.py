class car:   #Demo5_16.py
    """汽车模板"""
    def __init__(self,name,color,length,width,height,power):
        self.name  = name     #用变量定义品牌属性
        self.color   = color    #用变量定义颜色属性
        self.length  = length   #用变量定义长度属性
        self.width   = width    #用变量定义宽带属性
        self.height  = height   #用变量定义高度属性
        self.power  = power    #用变量定义功率属性
    def start(self):      # 定义汽车的启动功能
        pass    # 需进一步编程
    def accelerate(self): # 定义汽车的加速功能
        pass    # 需进一步编程
    def brake(self):      # 定义汽车的制动功能
        pass    # 需进一步编程

class truck(car):   #新建类（模板），并继承car类的属性和方法   #Demo5_16.py
    def __init__(self,name,color,length,width,height,power,load):
        super().__init__(name,color,length,width,height,power)
        self.load = load   #新建属性
    def drag(self):   #新建方法
        pass

oumanTruck = truck("foton","yellow",5800,2200,2400,15000,80)  #新类的对象
print(oumanTruck.name,oumanTruck.color,oumanTruck.load) #输出从car继承的和新建的属性
#执行结果
#foton yellow 80
