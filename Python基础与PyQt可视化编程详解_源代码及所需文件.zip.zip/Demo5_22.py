class student(object):   #Demo5_22.py
    def __init__(self,name,score):
        self.name = name
        self.score = score

    @property
    def getName(self):
        return self.name
    @property
    def getScore(self):
        return self.score

student1 = student("李某人",89)

sName = student1.getName
sScore = student1.getScore
print(sName,sScore)
