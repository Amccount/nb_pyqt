from openpyxl import Workbook  #Demo6_33.py
from openpyxl.chart import  Reference, LineChart ,LineChart3D

wbook = Workbook()
wsheet = wbook.active
accelerations = [ ("频率", "sensor1", "sensor2","sensor3"),
    (10, 1.2, 1.6,2.3),  (15, 2.1, 3.3,3.4), (20, 2.0, 1.8,2.1),
    (25, 4.4, 4.2,3.4),  (30, 3.5, 3.8,3.6), (35, 3.8, 3.7,4.5),
    (40, 3.2, 1.5,3.6),  (45, 2.5, 5.0,2.2), (50, 4.5, 3.1,2.1) ]
for data in accelerations:
    wsheet.append(data)
line = LineChart()
line_stacked = LineChart()
line_percent = LineChart()
line3D = LineChart3D()

line.title=line_stacked.title=line_percent.title=line3D.title = "加速度频谱"
line.x_axis.title=line_stacked.x_axis.title = "频率（Hz）"
line_percent.x_axis.title=line3D.x_axis.title= "频率（Hz）"
line.y_axis.title =line_stacked.y_axis.title= "加速度（m/s2）"
line_percent.y_axis.title =line3D.y_axis.title= "加速度（m/s2）"

line.grouping="standard"   #设置类型
line_stacked.grouping="stacked"  #设置类型
line_percent.grouping= "percentStacked"  #设置类型

xLabel = Reference(wsheet,min_col=1,min_row=2,max_row=10)
yData = Reference(wsheet,min_col=2,max_col=4,min_row=1,max_row=10)

line.add_data(yData,titles_from_data=True)
line_stacked.add_data(yData,titles_from_data=True)
line_percent.add_data(yData,titles_from_data=True)
line3D.add_data(yData,titles_from_data=True)

line.set_categories(xLabel)
line_stacked.set_categories(xLabel)
line_percent.set_categories(xLabel)
line3D.set_categories(xLabel)

marker={0:'triangle',1:'square',2:'circle'}
color={0:'FF0000',1:'00FF00',2:'0000FF'}
dash = {0:'dash',1:'solid',2:'dashDot'}
width = {0:10,1:20000,2:30000}
for i in range(3):
    line.series[i].marker.symbol = marker[i]    #设置符号样式
    line.series[i].marker.graphicalProperties.solidFill = color[i]  #设置符号填充颜色
    line.series[i].marker.graphicalProperties.line.solidFill = color[i]  #设置符号线颜色

    line.series[i].graphicalProperties.line.solidFill = color[i]  #设置线颜色
    line.series[i].graphicalProperties.line.dashStyle = dash[i]  #设置线型
    line.series[i].graphicalProperties.line.width= width[i]  #设置粗细
wsheet.add_chart(line,"A12")
wsheet.add_chart(line_stacked,"J12")
wsheet.add_chart(line_percent,"A30")
wsheet.add_chart(line3D,"J30")
wbook.save("d:\\python\\line.xlsx")
