def total(n):  #Demo6_3.py
    tt = 0
    for i in range(1,n+1):
        tt = tt+i
    return tt

if __name__ == "__main__":
    n = input("请输入正整数：")
    try:
        n = int(n)
        s = total(n)
        print("从1到{}的和是{}".format(n,s))
    except TypeError:
        print("！！！程序有问题，终止运行，请与软件开发商联系！！！")
    except ValueError as er:
        print(er)
        n = input("您的输入是{},输入不是正整数，请重新输入一次：".format(n))
        n = int(n)
        s = total(n)
        print("从1到{}的和是{}".format(n,s))
#运行结果：
#请输入正整数：shi
#invalid literal for int() with base 10: 'shi'
#您的输入是shi,输入不是正整数，请重新输入一次：10
#从1到10的和是55
