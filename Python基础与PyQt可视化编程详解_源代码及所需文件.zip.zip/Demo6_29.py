from openpyxl import load_workbook  #Demo6_29.py
from openpyxl.styles import Font, Border, Side, PatternFill,Color,Alignment,Protection

wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
side=Side(border_style='thin',color=Color('000000FF'))
wsheet['B2'].font = Font(name='华文中宋',size=20,bold=True,italic=False,
color=Color('00FF0000'))
wsheet['C3'].fill = PatternFill(patternType='solid',fgColor=Color('0080800F'),
bgColor=Color('00FFFF00'))
for i in wsheet[1]:   #下面对第一行所有单元格进行样式设置
    i.font=Font(name='黑体',sz =15,bold=True, italic=True,strike=True,
color=Color('00668790'))
    i.border=Border(left=side,right=side,top=side,bottom=side)
    i.fill = PatternFill(patternType='lightGray',fgColor=Color('00AA7799'),
bgColor=Color('00BBCCDD'))
    i.alignment=Alignment(horizontal='center',vertical='bottom')
    i.protection = Protection(locked=True, hidden=False)
wbook.save("d:\\python\\student.xlsx")
