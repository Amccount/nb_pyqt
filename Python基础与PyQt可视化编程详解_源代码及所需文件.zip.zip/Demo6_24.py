from openpyxl import load_workbook  #Demo6_24.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
wsheet.delete_rows(3)  #删除第3行
wsheet.delete_cols(2,4)   #删除第2列到第4列
wsheet.insert_rows(4)   #在第行插入空行
wsheet.insert_cols(2,5)  #在第2列到第5列插入空行
i = range(10)
wsheet.append(i)
