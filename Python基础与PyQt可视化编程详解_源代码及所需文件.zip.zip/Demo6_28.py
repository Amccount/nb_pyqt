from openpyxl import load_workbook  #Demo6_28.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']

wsheet.freeze_panes = "C3"
