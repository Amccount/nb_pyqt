class student(object):  # Demo5_28.py
    def __init__(self, name=None, number=None, score=None):
        self.name = name
        self.number = number
        self.score = score

    def setName(self, name):
        self.name = name

    def setNumber(self, number):
        self.number = number

    def setScore(self, score):
        self.score = score


# 学号是关键字，姓名和成绩是值
s_score = {20203: ("李明", 84), 20202: ("高新", 79), 20201: ("赵东", 92), 20204: ("李丽", 69)}

num = list()  # 学号列表
num.extend(s_score.keys())
num.sort()  # 按学号顺序从小到大排序

s_list = list()  # 空对象列表
s_dict = dict()  # 空对象字典
for i in num:
    temp = student()
    temp.setName(s_score[i][0])
    temp.setNumber(i)
    temp.setScore(s_score[i][1])
    s_list.append(temp)  # 将对象添加到列表中
    s_dict[i] = temp  # 将对象添加到字典中

template = "姓名：{} 学号：{} 成绩：{}"
for s in s_list:
    print(template.format(s.name, s.number, s.score))
s_tuple = tuple(s_list)  # 由对象构成的元组
s_set = set(s_list)  # 由对象构成的集合
# 运行结果
# 姓名：赵东 学号：20201 成绩：92
# 姓名：高新 学号：20202 成绩：79
# 姓名：李明 学号：20203 成绩：84
# 姓名：李丽 学号：20204 成绩：69
