from openpyxl import Workbook  #Demo6_37.py
from openpyxl.chart import Series, Reference, ScatterChart

wbook = Workbook()
wsheet = wbook.active
accelerations = [ ("频率1", "sensor1", "频率2","sensor2","频率3","sensor3"),
                  (10, 1.2,  12, 1.6,  14, 2.3),
                  (15, 2.1,  17, 3.3,  19, 3.4),
                  (20, 2.0,  22, 1.8,  24, 2.1),
                  (25, 4.4,  27, 4.2,  29, 3.4),
                  (30, 3.5,  32, 3.8,  34, 3.6),
                  (35, 3.8,  37, 3.7,  39, 4.5),
                  (40, 3.2,  42, 1.5,  44, 3.6),
                  (45, 2.5,  47, 5.0,  49, 2.2),
                  (50, 4.5,  52, 3.1,  54, 2.1)  ]
for data in accelerations:
    wsheet.append(data)
scatter = ScatterChart()
scatter.title = "加速度频谱"
scatter.style = 3
scatter.x_axis.title = "频率（Hz）"
scatter.y_axis.title = "加速度（m/s2）"
scatter.scatterStyle = "marker"

symbol = {0:"triangle",1:"square",2:"circle"}
color={0:'FF0000',1:'00FF00',2:'0000FF'}
for i in range(0,3):
    xLabel = Reference(wsheet, min_col=i*2+1, min_row=2, max_row=10)
    yData = Reference(wsheet,min_col=i*2+2,min_row=1,max_row=10)
    ser = Series(yData,xvalues=xLabel,title_from_data=True)
    ser.marker.symbol = symbol[i]  #设置符号
    ser.marker.graphicalProperties.solidFill = color[i]  #设置填充颜色
    ser.marker.graphicalProperties.line.solidFill = color[i]  #设置边框颜色
    ser.graphicalProperties.line.noFill = True  #隐藏线条
    scatter.append(ser)

wsheet.add_chart(scatter,"A12")
wbook.save("d:\\python\\scatter.xlsx")
