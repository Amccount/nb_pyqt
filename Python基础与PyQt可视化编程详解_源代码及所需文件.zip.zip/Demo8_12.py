import sys  #Demo8_12.py
from PyQt5.QtWidgets import (QApplication,QWidget,QPushButton,QComboBox,QTextEdit,
QCheckBox,QRadioButton, QVBoxLayout,QHBoxLayout,QAction,QMenu)
from PyQt5.QtCore import Qt

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle("按钮综合例子")
        self.resize(500, 400)
        self.setupUi()  #调用函数，建立界面上的控件
        self.pushMenu() #调用函数，为pushButton创建菜单
    def setupUi(self):  #建立界面上的控件
        self.pushButton = QPushButton("选择字体",self)
        self.checkBox_bold = QCheckBox("粗体",self)
        self.checkBox_italic = QCheckBox("斜体",self)
        self.checkBox_underline = QCheckBox("下划线",self)
        self.radioButton_left = QRadioButton("左对齐",self)
        self.radioButton_center =QRadioButton("居中",self)
        self.radioButton_right = QRadioButton("右对齐",self)
        self.comboBox = QComboBox(self)
        for i in range(4,30,2):
            self.comboBox.addItem(str(i))
        self.comboBox.setEditable(True)
        self.comboBox.setFixedWidth(100)
        self.comboBox.setCurrentText("选择字体尺寸")
        self.plainText = QTextEdit("很高兴认识你，Nice to meet you!",self)

        self.checkBox_bold.toggled.connect(self.bold)  #信号与槽的连接
        self.checkBox_italic.toggled.connect(self.italic)   #信号与槽的连接
        self.checkBox_underline.toggled.connect(self.underline)   #信号与槽的连接
        self.radioButton_left.toggled.connect(self.left)   #信号与槽的连接
        self.radioButton_center.toggled.connect(self.center)   #信号与槽的连接
        self.radioButton_right.toggled.connect(self.right)   #信号与槽的连接
        self.comboBox.currentTextChanged.connect(self.font_size)   #信号与槽的连接

        self.horizontalLayout = QHBoxLayout()  #水平布局控件
        self.horizontalLayout.addWidget(self.pushButton)
        self.horizontalLayout.addWidget(self.checkBox_bold)
        self.horizontalLayout.addWidget(self.checkBox_italic)
        self.horizontalLayout.addWidget(self.checkBox_underline)
        self.horizontalLayout.addWidget(self.radioButton_left)
        self.horizontalLayout.addWidget(self.radioButton_center)
        self.horizontalLayout.addWidget(self.radioButton_right)
        self.horizontalLayout.addWidget(self.comboBox)

        self.verticalLayout = QVBoxLayout(self)  #竖直布局控件
        self.verticalLayout.addWidget(self.plainText)
        self.verticalLayout.addLayout(self.horizontalLayout)
    def pushMenu(self):   #按钮中添加菜单
        self.action_song = QAction("宋体")   #定义动作
        self.action_hei = QAction("黑体")   #定义动作
        self.action_kai = QAction("楷体")   #定义动作
        self.action_hua = QAction("华文彩云")   #定义动作

        self.action_song.triggered.connect(self.family_song)  #动作与函数的连接
        self.action_hei.triggered.connect(self.family_hei)   #动作与函数的连接
        self.action_kai.triggered.connect(self.family_kai)   #动作与函数的连接
        self.action_hua.triggered.connect(self.family_hua)   #动作与函数的连接

        self.menu = QMenu(self)   #定义菜单
        self.menu.addAction(self.action_song)   #菜单中添加动作
        self.menu.addAction(self.action_hei)   #菜单中添加动作
        self.menu.addAction(self.action_kai)   #菜单中添加动作
        self.menu.addAction(self.action_hua)   #菜单中添加动作

        self.pushButton.setMenu(self.menu)  #按钮中添加菜单
    def bold(self,checked):   #粗体
        font = self.plainText.font()
        font.setBold(checked)
        self.plainText.setFont(font)
    def italic(self,checked):  #斜体
        font = self.plainText.font()
        font.setItalic(checked)
        self.plainText.setFont(font)
    def underline(self,checked):  #下划线
        font = self.plainText.font()
        font.setUnderline(checked)
        self.plainText.setFont(font)
    def left(self,checked):  #左对齐
        if checked:
            self.plainText.setAlignment(Qt.AlignLeft)
    def center(self,checked):  #居中
        if checked:
            self.plainText.setAlignment(Qt.AlignCenter)
    def right(self,checked):  #右对齐
        if checked:
            self.plainText.setAlignment(Qt.AlignRight)
    def font_size(self,text):  #字体大小
        font = self.plainText.font()
        font.setPointSize(int(text))
        self.plainText.setFont(font)
    def family_song(self):  #宋体字
        font = self.plainText.font()
        font.setFamily("宋体")
        self.plainText.setFont(font)
        self.pushButton.setText("宋体")
    def family_hei(self):  #黑体字
        font = self.plainText.font()
        font.setFamily("黑体")
        self.plainText.setFont(font)
        self.pushButton.setText("黑体")
    def family_kai(self):  #楷体字
        font = self.plainText.font()
        font.setFamily("楷体")
        self.plainText.setFont(font)
        self.pushButton.setText("楷体")
    def family_hua(self):  #华文彩云字
        font = self.plainText.font()
        font.setFamily("华文彩云")
        self.plainText.setFont(font)
        self.pushButton.setText("华文彩云")
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
