class person(object):   #Demo5_17.py
    nation = "汉族"  #类属性
    party = "群众"   #类属性
    def __init__(self,p_name,p_age):
        self.name = p_name   #实例属性
        self.age = p_age     #实例属性
        self.i = 0
    def output(self):
        self.i = self.i+1
        print("第{}次输出：{} {}".format(self.i,self.name,self.age)) #输出实例属性name和age

student = person(p_name = "李明",p_age = 15)  #用类person创建实例strudent
teacher = person(p_name = "王芳",p_age = 33)  #用类person创建实例teacher
student.output()    #第1次调用实例student的属性output()，输出实例属性name和age
teacher.output()    #第1次调用实例teacher的属性output()，输出实例属性name和age
student.name = "李学生"   #修改student的实例属性name
student.age = 18          #修改student的实例属性age
student.output()    #第2次调用实例student的属性output()，输出实例属性name和age
teacher.output()    #第2次调用实例teacher的属性output()，输出实例属性name和age

#运行结果
#第1次输出： 李明 15
#第1次输出： 王芳 33
#第2次输出： 李学生 18
#第2次输出： 王芳 33
