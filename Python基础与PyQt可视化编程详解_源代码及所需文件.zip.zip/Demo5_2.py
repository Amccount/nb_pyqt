def total(n):    #定义total()函数   #Demo5_2.py
    """计算从0到n的和"""
    if n>0:
        y = 0
        for i in range(1,n+1):
            y = y+i
        return y
    elif n<0:
        y = 0
        for i in range(-1,n-1,-1):
            y = y+i
        return y
    else:
        return 0
    print('hello')

x = input("请输入一个整数：")
x = int(x)     #将字符串转换成整数
xx = total(x)  #调用自定义函数total()
print("从0到{}的和是：{}".format(x,xx))
