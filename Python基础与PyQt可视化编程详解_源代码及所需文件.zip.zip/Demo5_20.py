import math  # Demo5_20.py

class h:
    factor = 2.0  # 类变量

    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.xuan = h.rms(self.x, self.y)  # 通过 类名.函数名() 引用静态函数

    @staticmethod
    def rms(a, b):
        return math.sqrt((a ** 2 + b ** 2) / 2) * h.factor  # 通过 类名.函数名() 引用类变量


a = h(3, 4)
print(a.xuan)
print(a.rms(3, 4))  # 通过 实例名.函数名() 引用静态函数
print(h.rms(3, 4))  # 通过 类名.函数名() 引用静态函数
