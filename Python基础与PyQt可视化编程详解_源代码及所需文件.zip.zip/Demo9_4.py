import sys,os  #Demo9_4.py
from PyQt5.QtWidgets import (QApplication,QAction,QMenuBar,QMenu,QPlainTextEdit,
                             QVBoxLayout,QWidget,QFileDialog)
from PyQt5.QtGui import QIcon
class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle("QAction")
        self.setupUi()
    def setupUi(self):
        menuBar = QMenuBar()  #创建菜单栏
        self.plainText = QPlainTextEdit() #创建文本编辑器
        vlayout = QVBoxLayout(self)  #创建竖直布局
        vlayout.addWidget(menuBar)
        vlayout.addWidget(self.plainText)

        act_new = QAction(QIcon("d:\\python\\new.png"),"新建(&N)", self)  #创建动作
        act_open = QAction(QIcon("d:\\python\\open.png"),"打开(&O)", self) #创建动作
        act_save = QAction(QIcon("d:\\python\\save.png"),"保存(&S)", self) #创建动作
        act_exit = QAction(QIcon("d:\\python\\exit.png"),"退出(&E)", self) #创建动作
        act_new.setShortcut("Ctrl+N")  #定义快捷键
        act_open.setShortcut("Ctrl+O")  #定义快捷键
        act_save.setShortcut("Ctrl+S")  #定义快捷键
        act_exit.setShortcut("Ctrl+E")  #定义快捷键

        menu_file = QMenu("文件(&F)",self)  #创建菜单
        menuBar.addMenu(menu_file)  #菜单栏中添加菜单
        menu_file.addAction(act_new)  #菜单中添加动作
        menu_file.addAction(act_open)  #菜单中添加动作
        menu_file.addAction(act_save)  #菜单中添加动作
        menu_file.addSeparator()  #菜单中添加分隔条
        menu_file.addAction(act_exit)  #菜单中添加动作

        menu_edit = menuBar.addMenu("编辑(&E)")  #菜单栏中添加菜单
        act_copy = menu_edit.addAction("复制(&C)") #菜单中添加动作
        act_cut = menu_edit.addAction("剪切(&X)") #菜单中添加动作
        act_paste = menu_edit.addAction("粘贴(&V)") #菜单中添加动作

        act_new.triggered.connect(self.act_new_triggered)  #信号与自定义槽的关联
        act_open.triggered.connect(self.act_open_triggered)
        act_save.triggered.connect(self.act_save_triggered)
        act_exit.triggered.connect(self.close)  #信号与窗口槽的关联
        act_copy.triggered.connect(self.plainText.copy)  #信号与控件的槽的关联
        act_cut.triggered.connect(self.plainText.cut)
        act_paste.triggered.connect(self.plainText.paste)
    def act_new_triggered(self):  #自定义槽函数
        self.plainText.clear()
    def act_open_triggered(self):  #自定义槽函数
        filename,filter = QFileDialog.getOpenFileName(self,"打开文件","d:\\","文本文件(*.txt)")
        if os.path.exists(filename):
            self.plainText.clear()
            fp = open(filename,"r",encoding="UTF-8")
            string = fp.readlines()
            for i in string:
                i = i.strip()
                self.plainText.appendPlainText(i)
            fp.close()
    def act_save_triggered(self):  #自定义槽函数
        filename,filter = QFileDialog.getSaveFileName(self,"打开文件","d:\\","文本文件(*.txt)")
        string = self.plainText.toPlainText()
        if filename != "":
            if os.path.exists(filename):
                fp=open(filename,"wa",encoding="UTF-8")
                fp.writelines(string)
                fp.close()
            else:
                fp = open(filename, "w", encoding="UTF-8")
                fp.writelines(string)
                fp.close()
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
