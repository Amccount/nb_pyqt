try:  # Demo6_8.py
    fp = open("D:\\Python\\student.txt", 'r', encoding='UTF-8')
    ss = fp.read()  # 读取文件内容
except:
    print("打开或读取文件失败！")
else:
    print("读取文件成功！文件内容如下：")
    print(ss)  # 输出读取的文件内容
    fp.close()

    ss = ss.strip()  # 去除前后的换行
    ss = ss.split('\n')  # 用换行分割，分割后ss是列表
    n = len(ss)
    for i in range(n):
        ss[i] = ss[i].split()  # 用空格分割，分割后ss[i]是列表
    ss[0].append('总成绩')
    ss[0].append("平均成绩")
    for i in range(1, n):
        total = int(ss[i][2]) + int(ss[i][3]) + int(ss[i][4]) + int(ss[i][5])  # 计算个人总成绩
        ss[i].append(str(total))
        ss[i].append(str(total / 4))

    template1 = "{:^6s}" * 8
    template2 = "{:<8s}" * 8
    print(template1.format(ss[0][0], ss[0][1], ss[0][2], ss[0][3], ss[0][4], ss[0][5], ss[0][6], ss[0][7]))
    for i in range(1, n):
        print(template2.format(ss[i][0], ss[i][1], ss[i][2], ss[i][3], ss[i][4], ss[i][5], ss[i][6], ss[i][7]))
# 运行结果：
# 读取文件成功！文件内容如下：
# 学号      姓名   语文    数学    物理    化学
# 202003   没头脑   89     88      93      87
# 202002   不高兴   80     71      88      98
# 202004   倒霉蛋   95     92      88      94
# 202001   鸭梨头   93     84      84      77
# 202005   墙头草   93     86      73      86
#
#  学号    姓名    语文    数学    物理    化学   总成绩   平均成绩
# 202003  没头脑     89      88      93      87      357     89.25
# 202002  不高兴     80      71      88      98      337     84.25
# 202004  倒霉蛋     95      92      88      94      369     92.25
# 202001  鸭梨头     93      84      84      77      338     84.5
# 202005  墙头草     93      86      73      86      338     84.5
