import sys   #Demo14_4.py
from PyQt5.QtWidgets import QApplication,QPushButton,QVBoxLayout,QHBoxLayout,QWidget
from PyQt5.QtMultimedia import QCamera
from PyQt5.QtMultimediaWidgets import QCameraViewfinder

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(800,600)
        self.setupUi()
    def  setupUi(self):  #界面
        self.viewfinder=QCameraViewfinder() #取景器
        btn_start=QPushButton("开启摄像头")
        btn_stop=QPushButton("停止摄像头")
        h=QHBoxLayout()  #水平布局
        h.addWidget(btn_start)
        h.addWidget(btn_stop)
        v=QVBoxLayout(self)  #竖直布局
        v.addWidget(self.viewfinder)
        v.addLayout(h)

        self.camera=QCamera(self)  #摄像头
        self.camera.setViewfinder(self.viewfinder)  #设置摄像头的取景器
        #self.viewfinder.setMediaObject(self.camera)  #也可以用取景器关联摄像头

        btn_start.clicked.connect(self.camera.start)
        btn_stop.clicked.connect(self.camera.stop)
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
