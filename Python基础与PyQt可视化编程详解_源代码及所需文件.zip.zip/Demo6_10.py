string = list()  #空列表  #Demo6_10.py
try:
    fp = open("D:\\Python\\student.txt",'r',encoding='UTF-8')
    while True:
        line = fp.readline()  #读取行数据
        if len(line)>0:
            line = line.strip()  # 去除行尾的\n
            if len(line)>0:
                string.append(line) #把数据放到string列表中
        else:
            break  #读到最后终止
except:
    print("打开或读取文件有误！")
else:
    fp.close()
finally:
    for i in string:
        print(i)
