from openpyxl import load_workbook   #Demo6_20.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
A1 = wsheet["A1"]  #用单元格名称定位单元格
E3 = wsheet["E3"]  #用单元格名称定位单元格
C5 = wsheet.cell(row=5,column=3)  #用工作表格的cell()方法，通过行列号定位单元格
print(A1.value,E3.value,C5.value,wsheet["B5"].value,)  #用value属性获取单元格的值

C5.value = 97 #赋值语句赋值
wsheet["D4"]= 93  #赋值语句赋值
wsheet.cell(row=3,column=5,value=89)  #用工作表格的cell()方法，通过行列号赋值
