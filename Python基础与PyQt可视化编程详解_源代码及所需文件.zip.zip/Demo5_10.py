def circle(radius):   #Demo5_10.py
    pi = 3.1415926
    area = pi*radius**2
    perimeter = 2*pi*radius

    return area,perimeter
# 下面是主程序
x = circle(10)   # x是元组
print(x[0],x[1],type(x))
x1,x2 = circle(10)  # x1和x2是浮点数
print(x1,x2,type(x1),type(x2))
#运行结果
#314.15926 62.831852 <class 'tuple'>
#314.15926 62.831852 <class 'float'> <class 'float'>
