def total(n):  #Demo6_2.py
    tt = 0
    for i in range(1,n+1):
        tt = tt+i
    return tt

if __name__ == "__main__":
    n = input("请输入正整数：")
    n = int(n)   #将字符串转成整数
    s = total(n)  #调用total()函数
print("从1到{}的和是{}".format(n,s))
#运行结果
#请输入正整数：shi
#Traceback (most recent call last):
#  File "D:/Python/try1.py", line 9, in <module>
#    n = int(n)
#ValueError: invalid literal for int() with base 10: 'shi'
