import sys  #Demo8_2.py
from PyQt5.QtWidgets import QApplication,QWidget,QLabel
from PyQt5.QtGui import QFont,QPalette,QColor
from random import  randint

class setPallete(QWidget):
    def __init__(self,parent=None):
        super(QWidget,self).__init__(parent)
        self.setGeometry(200,200,1200,500)  #设置窗口尺寸
        self.setWindowTitle("设置调色板实例")
        self.createLabels()  #调用函数
        self.setLabelColor()  #调用函数
        self.getLabelColorRGB()  #调用函数
    def createLabels(self):
        self.labels = list()
        font = QFont("黑体",pointSize=20)
        string = "Nice to meet you! 很高兴认识你！"
        for i in range(10):
            label = QLabel(self)  #在窗口上创建标签控件
            label.setGeometry(0,50*i,1200,40)  #标签位置和尺寸
            label.setText(str(i)+': '+string)  #设置标签文字
            label.setFont(font)  #设置标签文字的字体
            self.labels.append(label) #标签列表
    def setLabelColor(self):
        for i in self.labels:
            color = QColor(randint(0,255), randint(0,255), randint(0,255)) #定义颜色，RGB是随机值
            colorText = QColor(randint(0,255), randint(0,255), randint(0,255))  #定义颜色
            palette = QPalette()
            palette.setColor(palette.Active,palette.Window,color)  #定义背景色
            palette.setColor(palette.Active,palette.WindowText,colorText) #定义前景色
            i.setAutoFillBackground(True)  #设置背景自动填充
            i.setPalette(palette)  #设置调色板

    def getLabelColorRGB(self):
        for i in self.labels:
            r = i.palette().window().color().red()  #获取背景颜色红色值
            g = i.palette().window().color().green()  #获取背景颜色绿色值
            b = i.palette().window().color().blue()  #获取背景颜色蓝色值
            rT = i.palette().windowText().color().red()  #获取文字颜色红色值
            gT = i.palette().windowText().color().green()  #获取文字颜色绿色值
            bT = i.palette().windowText().color().blue()  #获取文字颜色蓝色值

            text = "{} {} {} {} {} {} {} {} {}".format(i.text(),
                    "背景颜色：",r,g,b,"文字颜色：",rT,gT,bT)
            i.setText(text)
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = setPallete()
    window.show()
    n= app.exec()
    sys.exit(n)
