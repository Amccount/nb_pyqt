import sys  #Demo8_19.py
from PyQt5.QtWidgets import QApplication,QWidget,QPushButton
from PyQt5.QtGui import QPainter,QPixmap,QBitmap
from PyQt5.QtCore import QRect,QTimer

class myWindow (QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle("定时器")
        path = "d:\\python\\pic.png"
        self.pix = QPixmap(path)
        self.bit = QBitmap(path)
        self.rect = QRect(0, 0, self.pix.width(),self.pix.height())
        self.resize(self.rect.size())

        self.timer_1 = QTimer(self)  #第1个定时器
        self.timer_1.setInterval(2000)
        self.timer_1.timeout.connect(self.timer_1_slot)  #定时器信号与槽函数的连接
        self.timer_1.start()
        self.status = True  #指示变量

        self.timer_2 = QTimer(self)  #第2个定时器
        self.timer_2.setInterval(1000)
        self.timer_2.timeout.connect(self.pushButton_enable)  #定时器信号与槽函数的连接
        self.status = True
        self.i = 9 #按钮激活时间
        self.pushButton = QPushButton("单击发送验证码",self)
        self.pushButton.setGeometry(10,10,200,30)
        self.pushButton.clicked.connect(self.timer_2_start) #按钮单击信号与槽函数的连接
    def timer_1_slot(self):
        self.status = not self.status
        self.update()
    def paintEvent(self, event):
        painter = QPainter(self)
        if self.status:
            painter.drawPixmap(self.rect,self.pix)
        else:
            painter.drawPixmap(self.rect, self.bit)
    def timer_2_start(self):
        self.timer_2.start()
        self.pushButton.setEnabled(False)
        self.pushButton.setText(str(self.i+1)+"后可重新发送验证码")
    def pushButton_enable(self):
        if self.i>0 :
            self.pushButton.setText(str(self.i)+"后可重新发送验证码")
            self.i = self.i - 1
        else:
            self.pushButton.setEnabled(True)
            self.pushButton.setText("单击发送验证码")
            self.timer_2.stop()  #停止定时器
            self.i = 9
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    n= app.exec()
    sys.exit(n)
