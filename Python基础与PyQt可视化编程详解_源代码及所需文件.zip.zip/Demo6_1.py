am = [1,2,3,4]  #Demo6_1.py
print(am)
x= 0
for i in range(10):
    x= x+am[i]
print(x)
#运行结果：
#[1, 2, 3, 4]
#Traceback (most recent call last):
#  File "D:/Python/error.py", line 5, in <module>
#    x= x+am[i]
#IndexError: list index out of range
