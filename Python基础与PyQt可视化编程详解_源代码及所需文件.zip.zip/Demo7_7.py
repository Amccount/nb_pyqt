import sys  #Demo7_7.py
from PyQt5.QtWidgets import QApplication, QWidget

import myUi  #导入myUi.py文件

def QmyWidget(parent = None):
    widget = QWidget(parent) #用QWidget对象widget,执行QWidget类的__init__()函数
    ui = myUi.QmyUi()  # 实例化myUi.py文件中的QmyUi类
    ui.setupUi(widget)  # 调用QmyUi类的setupUi()，以widget为实参传递给形参window
    ui.button.setText("Close")  # 重新设置按钮的显示文字
    ui.button.clicked.connect(widget.close)  # 窗口上的按钮事件与窗口事件关联

    return widget   #函数的返回值是窗口

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = QmyWidget()  #调用QmyWidget（）函数，返回值是窗口
    myWindow.show()
    n = app.exec()
    sys.exit(n)
