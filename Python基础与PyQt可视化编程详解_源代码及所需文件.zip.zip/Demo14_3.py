import sys  #Demo14_3.py
from PyQt5.QtWidgets import QApplication,QMainWindow,QGraphicsScene,\
                 QGraphicsView,QGraphicsItem,QFileDialog
from PyQt5.QtCore import QRectF,QUrl,QSizeF
from PyQt5.QtGui import QTransform
from PyQt5.QtMultimedia import QMediaPlayer,QMediaContent,QMediaPlaylist
from PyQt5.QtMultimediaWidgets import QGraphicsVideoItem

class myWindow(QMainWindow):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(800,600)
        self.setupUI()
    def setupUI(self):
        self.graphicsView = QGraphicsView()  # 视图窗口
        self.setCentralWidget(self.graphicsView)
        rectF = QRectF(-400, -300, 800, 600)
        self.graphicsScene = QGraphicsScene(rectF)  # 创建场景
        self.graphicsView.setScene(self.graphicsScene)  # 视图窗口设置场景
        self.videoItem = QGraphicsVideoItem()  #视频图项
        self.videoItem.setSize(QSizeF(400,300))
        self.videoItem.setFlags(QGraphicsItem.ItemIsSelectable|QGraphicsItem.ItemIsMovable)
        self.graphicsScene.addItem(self.videoItem)  #场景中添加视频图项
        self.videoItem.setPos(-300,-100)
        self.videoItem.setTransform(QTransform().shear(1,-0.5))  #错切
        self.player=QMediaPlayer(self)  #视频播放器
        self.videoItem.setMediaObject(self.player)  #视频图项设置播放器

        menubar=self.menuBar()
        file=menubar.addMenu("文件")  #菜单
        action_open=file.addAction("打开视频文件")
        action_open.triggered.connect(self.action_open_triggered)
    def action_open_triggered(self):
        fileNames, fil = QFileDialog.getOpenFileNames(self, caption="选择文件", directory="d:\\",
filter="影音文件(*.wav *.mp4 *.mp3 *.wma *.avi *.wmv *.rm* *.asf);;所有文件(*.*)")
        playlist = QMediaPlaylist(self)  # 创建播放列表
        playlist.setPlaybackMode(QMediaPlaylist.Loop)  # 设置循环播放模式
        if len(fileNames):
            for filename in fileNames:
                url = QUrl.fromLocalFile(filename)  # URL地址
                content = QMediaContent(url)  # 播放媒体
                playlist.addMedia(content)  # 添加到播放列表
            self.player.setPlaylist(playlist)  # 设置播放器的播放列表
            self.player.play()
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
