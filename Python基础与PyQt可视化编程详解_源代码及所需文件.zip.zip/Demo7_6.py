import sys  #Demo7_6.py
from PyQt5.QtWidgets import QApplication, QWidget

import myUi  #导入myUi.py文件

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = QWidget()

    ui = myUi.QmyUi()  #用myUi文件中的QmyUi类创建实例ui
    ui.setupUi(myWindow)  #调用ui的方法setupUi()，并以窗口实例作为实参
    ui.button.setText("Close")  #重新设置按钮的显示文字
    ui.button.clicked.connect(myWindow.close)  #窗口上的按钮事件与窗口事件关联

    myWindow.show()
    n = app.exec()
    sys.exit(n)
