import sys  #Demo14_7.py
from PyQt5.QtWidgets import QApplication,QPushButton,QHBoxLayout,QWidget,QFileDialog
from PyQt5.QtCore import QFile
from PyQt5.QtMultimedia import QAudioInput,QAudioOutput,QAudioDeviceInfo

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi()
    def  setupUi(self):  #界面
        btn_path=QPushButton("设置保存路径和文件名")
        btn_record=QPushButton("开始录制")
        self.btn_pause=QPushButton("暂停录制")
        btn_stop=QPushButton("停止录制")
        btn_play=QPushButton("开始播放")
        self.btn_suspend=QPushButton("暂停播放")
        btn_terminate=QPushButton("停止播放")

        h=QHBoxLayout(self)  #水平布局
        h.addWidget(btn_path)
        h.addWidget(btn_record)
        h.addWidget(self.btn_pause)
        h.addWidget(btn_stop)
        h.addWidget(btn_play)
        h.addWidget(self.btn_suspend)
        h.addWidget(btn_terminate)

        self.fileName = "d:/a.raw"
        self.file = QFile(self.fileName)  #初始化文件设备
        btn_path.clicked.connect(self.btn_path_clicked)  #信号与槽的连接
        btn_record.clicked.connect(self.btn_record_clicked)
        self.btn_pause.clicked.connect(self.btn_pause_clicked)
        btn_stop.clicked.connect(self.btn_stop_clicked)
        btn_play.clicked.connect(self.btn_play_clicked)
        self.btn_suspend.clicked.connect(self.btn_suspend_clicked)
        btn_terminate.clicked.connect(self.btn_terminate_clicked)
    def btn_path_clicked(self):  #获取文件路径和文件名
        self.fileName, fil = QFileDialog.getSaveFileName(self, caption="设置声音文件",
                                 directory='d:/', filter="原生文件(*.raw);;所有文件(*.*)")
    def btn_record_clicked(self):  #录制原生音频数据
        self.file.close()
        if self.fileName != "":
            self.file = QFile(self.fileName)
            self.inputDevice=QAudioDeviceInfo.defaultInputDevice()  #获取默认的音频输入设备
            if not self.inputDevice.isNull():
                self.file.open(QFile.WriteOnly)  #打开文件设备
                self.format=self.inputDevice.preferredFormat()  #输入设备的默认格式
                self.audioInput=QAudioInput(self.inputDevice,self.format,self) #音频输入
                self.audioInput.start(self.file)  #录制音频数据
    def btn_pause_clicked(self):
        if self.btn_pause.text()=="暂停录制":
            self.audioInput.suspend()  #暂停录制
            self.btn_pause.setText("继续录制")
        elif self.btn_pause.text()=="继续录制":
            self.audioInput.resume()  #继续录制
            self.btn_pause.setText("暂停录制")
    def btn_stop_clicked(self):
        self.audioInput.stop()  #停止录制
        self.file.close()
    def btn_play_clicked(self):
        self.file.close()
        self.file=QFile(self.fileName)
        self.outputDevice=QAudioDeviceInfo.defaultOutputDevice()  #获取默认的输出设备
        self.audioOutput=QAudioOutput(self.outputDevice,self.format,self)  #音频输出
        self.file.open(QFile.ReadOnly)  #打开文件设备
        self.audioOutput.start(self.file)  #播放音频
    def btn_suspend_clicked(self):
        if self.btn_suspend.text()=="暂停播放":
            self.audioOutput.suspend()  #暂停播放
            self.btn_suspend.setText("继续播放")
        elif self.btn_suspend.text()=="继续播放":
            self.audioOutput.resume()  #继续播放
            self.btn_suspend.setText("暂停播放")
    def btn_terminate_clicked(self):
        self.audioOutput.stop()  #停止播放
        self.file.close()
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
