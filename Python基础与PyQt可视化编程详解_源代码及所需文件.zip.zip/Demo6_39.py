from openpyxl import Workbook  #Demo6_39.py
from openpyxl.chart import  Reference, Series , ScatterChart, axis
from copy import deepcopy

wbook = Workbook()
wsheet = wbook.active
octave = [ ("中心频率", "Pressure dB"),
           (6.3, 63.5),  (12.5, 73.8), (31.5, 53.2),  (63, 82.5),
           (125, 64.5),  (250,  84.3), (500,94.5) ,  (1000, 74.5) ,
           (2000,67.5),(4000, 87.5) ,  (8000, 92.1) ,(16000, 74.2) ]
for data in octave:
    wsheet.append(data)
scatter1 = ScatterChart()
scatter1.title = "倍频程声压dB"
scatter1.x_axis.title = "频率(Hz)"
scatter1.y_axis.title = "声压（dB）"
scatter1.width = 12
scatter1.height = 8
scatter1.legend = None

xvalue = Reference(wsheet,min_col=1,min_row=2,max_row=13)
yvalue = Reference(wsheet,min_col=2,min_row=2,max_row=13)
ser = Series(yvalue,xvalues=xvalue,title="Pressure(dB)")
scatter1.append(ser)

scatter1.x_axis.minorTickMark = 'cross'  #设置次坐标显示位置，可选'in'、'out'、'cross'
scatter1.x_axis.majorTickMark = 'out'  #设置主坐标显示位置，可选'in'、'out'、'cross'
scatter1.y_axis.minorTickMark = 'in'  #设置次坐标显示位置，可选'in'、'out'、'cross'
wsheet.add_chart(scatter1,'A15')

scatter2 = deepcopy(scatter1)  #复制scatter1
scatter2.x_axis.scaling.logBase = 10  #x轴以对数显示
scatter2.x_axis.minorGridlines = axis.ChartLines()  #显示次坐标
wsheet.add_chart(scatter2,"J15")

scatter3 = deepcopy(scatter2)   #复制scatter2
scatter3.x_axis.scaling.min = 5  #设置x轴最小值
scatter3.x_axis.scaling.max = 16000  #设置x轴最大值
scatter3.y_axis.scaling.min = 50  #设置y轴最小值
scatter3.y_axis.scaling.max = 100  #设置y轴最大值
wsheet.add_chart(scatter3,'A35')

scatter4 = deepcopy(scatter3)
scatter4.x_axis.scaling.orientation = "maxMin" #设置坐标轴数值从大到小
scatter4.x_axis.crosses='max' #设置坐标轴的位置，可以选择'autoZero','max','min'
scatter4.x_axis.tickLblPos= 'low' #设置坐标标识的位置，可以选择'nextTo','low','high'
wsheet.add_chart(scatter4,'J35')

wbook.save("d:\\python\\axis.xlsx")
