import sys  #Demo10_5.py
from PyQt5.QtWidgets import QApplication,QWidget,QPushButton,QFrame,QHBoxLayout
from PyQt5.QtGui import QDrag
from PyQt5.QtCore import QPoint,QMimeData,Qt

class myPushButton(QPushButton):
    def __init__(self, parent=None):
        super().__init__(parent)
    def mousePressEvent(self, event):  #按键事件
        if event.button() == Qt.LeftButton:
            drag = QDrag(self)
            drag.setHotSpot(event.pos()-self.rect().topLeft())
            mime = QMimeData()
            drag.setMimeData(mime)
            drag.exec()
class myFame(QFrame):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setFrameShape(QFrame.Box)
        self.btn_1 = myPushButton(self)
        self.btn_1.setText("push button 1")
        self.btn_1.move(100,100)
        self.btn_2 = myPushButton(self)
        self.btn_2.setText("push button 2")
        self.btn_2.move(200,200)
    def dragEnterEvent(self,event):
        self.child = self.childAt(event.pos())  #获取指定位置的控件
        event.accept()
    def dragMoveEvent(self,event):
        if self.child:
            center = QPoint(int(self.child.width() / 2), int(self.child.height() / 2))
            self.child.move(event.pos() - center)
    def dropEvent(self,event):
        if self.child:
            center = QPoint(int(self.child.width() / 2), int(self.child.height() / 2))
            self.child.move(event.pos() - center)
class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi()
        self.resize(600,400)
        self.setAcceptDrops(True)
    def setupUi(self):
        self.frame_1= myFame(self)
        self.frame_2 =myFame(self)
        H = QHBoxLayout(self)
        H.addWidget(self.frame_1)
        H.addWidget(self.frame_2)
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())

