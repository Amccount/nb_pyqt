import sys,math   #Demo13_2.py
from PyQt5.QtWidgets import QApplication,QMainWindow,QPlainTextEdit,QFileDialog
from PyQt5.QtCore import QFile,QTextStream

class myWindow(QMainWindow):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(800,600)
        self.setupUI()  #界面
        self.fileName = "d:\\sin_cos.txt"  #"d:/sin_cos.txt" 写入的文件
    def setupUI(self):  #界面建立
        self.plainText = QPlainTextEdit()
        self.setCentralWidget(self.plainText)
        self.status=self.statusBar()
        self.menubar = self.menuBar()  # 菜单栏
        self.file=self.menubar.addMenu('文件')  #文件菜单
        action_textCreate=self.file.addAction('生成文件')  #动作
        action_textCreate.triggered.connect(self.textCreate_triggered)  #动作与槽的连接
        action_textOpen = self.file.addAction('打开文件')
        action_textOpen.triggered.connect(self.textOpen_triggered)
        self.file.addSeparator()
        action_close = self.file.addAction('关闭')
        action_close.triggered.connect(self.close)
    def textCreate_triggered(self):
        file=QFile(self.fileName)
        try:
            if file.open(QFile.WriteOnly | QFile.Text | QFile.Truncate): #打开文件
                writer=QTextStream(file)  #创建文本流
                writer.setCodec("UTF-8")  #设置编码
                writer.setFieldWidth(16)  #设置域宽
                writer.setFieldAlignment(QTextStream.AlignCenter)  #设置对齐方式
                writer.setRealNumberPrecision(6)  #设置小数位数
                writer.setRealNumberNotation(QTextStream.ScientificNotation)  #科学计数法
                writer << "x(度)" << "sin(x)" <<"cos(x)" << "sin(x)+cos(x)"  #写入流数据
                writer.setFieldWidth(0)  #设置域宽
                writer << "\n"  #写入回车换行
                for i in range(360):
                    r=i/180*math.pi
                    writer.setFieldWidth(16)
                    writer << i << math.sin(r) << math.cos(r) << math.sin(r)+math.cos(r)
                    writer.setFieldWidth(0)
                    writer << "\n"
        finally:
            self.status.showMessage("写入文件成功！")
        file.close()
    def textOpen_triggered(self):
        (fileName, fil) = QFileDialog.getOpenFileName(self, caption="打开文本文件",
                     directory="d:\\",filter="文本文件(*.txt);;所有文件(*.*)")
        file = QFile(fileName)
        try:
            if file.open(QFile.ReadOnly | QFile.Text):  #打开文件
                self.plainText.clear()
                reader = QTextStream(file)
                reader.setCodec("UTF-8")
                reader.setAutoDetectUnicode(True)
                string=reader.readAll()  #读取所有数据
                self.plainText.appendPlainText(string)
        finally:
            self.status.showMessage("打开文件成功！")
        file.close()
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
