import sys  #Demo10_8.py
from PyQt5.QtWidgets import QApplication,QWidget,QPushButton,QFrame,QHBoxLayout
from PyQt5.QtGui import QDrag
from PyQt5.QtCore import QPoint,QMimeData,Qt,QEvent

class myPushButton(QPushButton):
    def __init__(self,name=None,parent=None):
        super().__init__(parent)
        self.setText(name)
    def mousePressEvent(self, event):  #按键事件
        if event.button() == Qt.LeftButton:
            drag = QDrag(self)
            drag.setHotSpot(event.pos()-self.rect().topLeft())
            mime = QMimeData()
            drag.setMimeData(mime)
            drag.exec()
class myFrame(QFrame):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setFrameShape(QFrame.Box)
    def dragEnterEvent(self,event):
        self.child = self.childAt(event.pos())  #获取指定位置的控件
        if self.child:
            event.accept()
        else:
            event.ignore()
    def dragMoveEvent(self,event):
        if self.child:
            self.__center = QPoint(int(self.child.width() / 2), int(self.child.height() / 2))
            self.child.move(event.pos() - self.__center)
class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setupUi()
        self.resize(600,400)
        self.setAcceptDrops(True)
    def setupUi(self):
        self.frame_1 = myFrame(self)
        self.frame_2 = myFrame(self)
        H = QHBoxLayout(self)
        H.addWidget(self.frame_1)
        H.addWidget(self.frame_2)
        self.btn1 = myPushButton("button 1",self.frame_1)  #定义第1个按钮
        self.btn2 = myPushButton("button 2",self.frame_2)  #定义第2个按钮

        self.btn1.installEventFilter(self)  #将btn1的事件注册到窗口self上
        self.btn2.installEventFilter(self)  #将btn2的事件注册到窗口self上
    def eventFilter(self,watched,event):  #事件过滤函数
        if watched == self.btn1 and event.type()==QEvent.Move:
            self.btn2.move(event.pos())
            return True
        if watched == self.btn2 and event.type()==QEvent.Move:
            self.btn1.move(event.pos())
            return True
        return super().eventFilter(watched,event)
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
