from enum import IntEnum,unique   #Demo5_36.py

@unique
class weekday(IntEnum):
    Sunday = 0
    Monday = 1
    Tuesday = 2
    Wednsday = 3
    Thursday = 4
    Friday = 5
    Saturday = 6
print(weekday.Monday.name)  #获取名称属性
print(weekday.Monday.value)  #获取值属性
print(weekday["Monday"]) #通过成员名称获取成员
print("第5天是",weekday(5)) #通过成员值获取成员
for i in weekday:  #遍历
    print(i)
for key,value in weekday.__members__.items():
    print(key,value)
for key in weekday.__members__.keys():
    print(key)
for value in weekday.__members__.values():
    print(value)
weekend= weekday.Saturday | weekday.Sunday
