import math   #Demo5_13.py
z = lambda x,y: math.sqrt(x**2-y**2)

print(z(5,4))
print(z(5,3))
print(z(10,5))
#运行后的结果
#3.0
#4.0
#8.660254037844387
