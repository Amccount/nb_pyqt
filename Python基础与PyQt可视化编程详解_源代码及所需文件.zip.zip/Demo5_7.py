def total(*para):   #para是元组   #Demo5_7.py
    n = len(para)
    s = 0
    for i in range(n):
        s = s+para[i]
    return s

x = total(10,4,-2,3)    #调用函数，可以输入任意多个实参
print(x)
x = total(-4,6,9,10,-3,8,11,15)  #调用函数，可以输入任意多个实参
print(x)
