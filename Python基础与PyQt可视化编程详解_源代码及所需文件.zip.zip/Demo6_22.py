from openpyxl import load_workbook  #Demo6_22.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
cell_range = wsheet["A2:F6"]  #单元格切片，返回值cell_rang是按行排列的单元格对象元组
for i in cell_range:  # i是行单元格对象元组
    for j in i:  # j是单元格对象
        print(j.value,end=' ')  # 输出元组中单元格对象的值
    print('\n')
columnA = wsheet['A']  # columA是A列单元格对象元组
row1 = wsheet['1']  # row1是第1行单元格对象元组
row2 = wsheet[2]  # row2是第2行单元格对象元组
columnB_F = wsheet["B:F"]  # columnB_F是从B列到F列单元格对象元组
row1_2 = wsheet["1:2"]  # row1_2是第1列到第2列单元格对象元组
row3_5 = wsheet[3:5]  # row3_5是第3列到第5列单元格对象元组
for i in columnA:   # i是A列中单元格对象
   print(i.value,end=' ')
print("\n")
for i in columnB_F:  # i是列单元格对象元组
    for j in i:   # j是单元格对象
        print(j.value,end=' ')
    print('\n')
for i in row3_5:  # i是行单元格对象元组
    for j in i:  # j是单元格对象
        print(j.value,end=' ')
    print('\n')
for i in wsheet.values:  # 输出工作表格中所有单元格的值
    for j in i:
        print(j,end=' ')
    print('\n')
