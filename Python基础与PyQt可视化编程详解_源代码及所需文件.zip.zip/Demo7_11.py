import  os  #Demo7_11.py

ui = 'student.ui'   #被转换的ui文件
py = 'student.py'   #转换后的py文件
path = 'd:\\python'   #ui文件所在路径
os.chdir(path)  #将ui文件所在路径设置成当前路径
cmdTemplate = "pyuic5  -o  {py}  {ui}".format(py=py,ui=ui)  #文本模板
os.system(cmdTemplate)  #执行转换命令
