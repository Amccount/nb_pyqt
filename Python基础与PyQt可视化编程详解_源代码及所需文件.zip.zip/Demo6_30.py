from openpyxl import load_workbook  #Demo6_30.py
from openpyxl.styles import Font, PatternFill,Color
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']

wsheet.row_dimensions[1].height=30
wsheet.column_dimensions['A'].width =20

wsheet.column_dimensions['B'].font= Font(name='黑体',sz =15,bold=True,
                       italic=True,strike=True,color=Color('00FF0000'))
wsheet.column_dimensions['B'].fill = PatternFill(patternType='lightGray',
                       fgColor = Color('0000FF00'),bgColor = Color('000000FF'))
wbook.save("d:\\python\\student.xlsx")
