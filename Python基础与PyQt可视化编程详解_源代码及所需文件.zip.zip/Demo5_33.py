# sub_module.py   #Demo5_33.py
def module_test():
    if __name__ == "__main__":  # 变量__name__记录程序运行时的模块名
        print("我在主程序中运行")
    else:
        print("我在{}模块中运行".format(__name__))

module_test()
print("模块测试")
#直接运行结果：
#我在主程序中运行
#模块测试
