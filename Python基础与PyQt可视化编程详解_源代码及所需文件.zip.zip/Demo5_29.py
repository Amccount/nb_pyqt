class person(object):  # Demo5_29.py
    def __init__(self, name=None):
        self.__name = name

    def setName(self, name):
        self.__name = name

    def getName(self):
        return self.__name


class student(person):
    def __init__(self, name=None, number=None, score=None):
        super().__init__(name)
        self.__number = number
        self.__score = score

    def setNumber(self, number):
        self.__number = number

    def setScore(self, score):
        self.__score = score

    def getNumber(self):
        return self.__number

    def getScore(self):
        return self.__score


class teacher(person):
    def __init__(self, name=None):
        super().__init__(name)
        self.__myStudent = list()  # 用于存放学生对象的列表

    # 设置学生信息，形参student_information是字典，用于传递学生信息，关键字是学号
    def setMyStudent(self, student_information):
        num = list()  # 临时列表，用于存放学生的学号
        num.extend(student_information.keys())  # 从字典中获取学生的学号
        num.sort()  # 对学号排序
        for i in num:
            temp = student()  # 创建学生的对象，临时变量
            temp.setNumber(i)  # 设置学生对象的学号
            temp.setName(student_information[i][0])  # 设置学生对象的姓名
            temp.setScore(student_information[i][1])  # 设置学生对象的成绩
            self.__myStudent.append(temp)  # 将学生对象添加到学生列表中

    # 根据学号，查询和读取学生信息，形参number是学号
    def getMyStudent(self, number):
        if len(self.__myStudent) == 0:  # 在查询前确认已经读取了学生信息
            print("请先输入学生信息。")
            return None
        for i in self.__myStudent:
            if number == i.getNumber():  # 如果查询到学号，输出学生信息并返回学生对象
                template = "查询到的学生信息:\n姓名：{} 学号：{} 成绩：{}"
                print(template.format(i.getName(), i.getNumber(), i.getScore()))
                return i  # 函数返回值是学生对象
        print("！！！查无此学生！！！")  # 如果查询不到学生，返回提示信息。


# 以字典形式存储学生信息，键是学号
s_score = {20203: ("李明", 84), 20202: ("高新", 79), 20201: ("赵东", 92), 20204: ("李丽", 69)}

wang = teacher("王老师")  # 王老师对象
wang.getMyStudent(20203)  # 在未输入学生信息前进行查询，返回提示信息：请先输入学生信息
print("*" * 50)
wang.setMyStudent(s_score)  # 输入学生信息
wang.getMyStudent(20202)  # 根据学号查询学生信息
print("*" * 50)
s = wang.getMyStudent(20204)  # 根据学号查询学生信息，并返回学生对象
print("{}的学生信息\t姓名：{} 学号：{} 成绩：{}".format(wang.getName(), s.getName(), s.getNumber(), s.getScore()))
print("*" * 50)
wang.getMyStudent(20208)  # 查询不存在的学号，返回提示信息：！！！查无此学生！！！

# 运行结果如下：
# 请先输入学生信息。
# **************************************************
# 查询到的学生信息:
# 姓名：高新 学号：20202 成绩：79
# **************************************************
# 查询到的学生信息:
# 姓名：李丽 学号：20204 成绩：69
# 王老师的学生信息	姓名：李丽 学号：20204 成绩：69
# **************************************************
# ！！！查无此学生！！！
