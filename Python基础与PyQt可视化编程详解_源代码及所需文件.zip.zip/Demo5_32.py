# run.py   #Demo5_32.py
from student import st,total,average

s1 = st(name="李明",number=20201,score=89)  #直接使用类st
s2 = st(name="高新",number=20202,score=93)  #直接使用类st
s3 = st(name="李丽",number=20203,score=91)  #直接使用类st

tot = total(s1.score,s2.score,s3.score)     #直接调用函数total()
avg = average(s1.score,s2.score,s3.score)  #直接调用函数average()

print("三个学生的总成绩{}，平均成绩{}".format(tot,avg))
