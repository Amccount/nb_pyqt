import sys   #Demo14_5.py
from PyQt5.QtWidgets import QApplication,QPushButton,QVBoxLayout,QHBoxLayout,\
                         QWidget,QFileDialog,QDialog
from PyQt5.QtCore import QFileInfo
from PyQt5.QtGui import QPainter
from PyQt5.QtMultimedia import QCamera,QCameraViewfinderSettings,\
    QCameraImageCapture,QImageEncoderSettings,QMultimedia,QVideoFrame
from PyQt5.QtMultimediaWidgets import QCameraViewfinder

class image_browser(QDialog):  #对话框，用于显示捕捉到的图像
    def __init__(self,image,parent=None):
        super().__init__(parent)
        self.setWindowTitle("预览图片")
        self.__image=image
        self.resize(self.__image.width(),self.__image.height())
    def paintEvent(self,event):
        painter=QPainter(self)
        painter.drawImage(self.rect(),self.__image)
        super().paintEvent(event)
class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(800,600)
        self.setupUi()
    def  setupUi(self):  #界面
        self.viewfinder=QCameraViewfinder() #取景器
        btn_path=QPushButton("设置保存路径和文件名")
        btn_save=QPushButton("保存到文件并预览...")
        btn_buffer=QPushButton("保存到缓存并预览...")
        h=QHBoxLayout()  #水平布局
        h.addWidget(btn_path)
        h.addWidget(btn_save)
        h.addWidget(btn_buffer)
        v=QVBoxLayout(self)  #竖直布局
        v.addWidget(self.viewfinder)
        v.addLayout(h)

        self.camera=QCamera(self)  #摄像头
        self.camera.setViewfinder(self.viewfinder)  # 设置摄像头的取景器
        self.imageCapture = QCameraImageCapture(self.camera)  #定义图像捕捉对象
        self.imageCodecs=self.imageCapture.supportedImageCodecs()  #获取图形保存格式
        self.fileName = ""  #记录保存文件的文件名(含扩展名)
        self.camera.start()  #启动摄像头
        cameraSettings = QCameraViewfinderSettings()
        resolutions=self.camera.supportedViewfinderResolutions(cameraSettings)  #摄像头分辨率
        n=len(resolutions)
        if n:
            cameraSettings.setResolution(resolutions[n-1])
            self.camera.setViewfinderSettings(cameraSettings)  #设置分辨率
        btn_path.clicked.connect(self.btn_path_clicked)  #按钮信号与槽函数关联
        btn_save.clicked.connect(self.btn_save_clicked)  #按钮信号与槽函数关联
        btn_buffer.clicked.connect(self.btn_buffer_clicked)  #按钮信号与槽函数关联
        self.imageCapture.imageCaptured.connect(self.image_captured)  #捕捉信号与槽函数关联
    def btn_path_clicked(self):
        file_filter='所有文件(*.*)'
        for i in self.imageCodecs:
            file_filter="{}文件(*.{});;".format(i,i)+file_filter  #文件过滤器
        self.fileName,fil=QFileDialog.getSaveFileName(self,caption="设置图像文件名和类型",
                                            directory='d:/',filter=file_filter)
    def btn_save_clicked(self):
        if self.fileName == '': return
        fileInfo = QFileInfo(self.fileName)
        extension = fileInfo.suffix()  # 获取扩展名，图像文件的类型
        if extension in self.imageCodecs:
            if self.imageCapture.isReadyForCapture():
                self.camera.setCaptureMode(QCamera.CaptureStillImage)  # 设置捕捉模式
                self.imageCapture.setCaptureDestination(QCameraImageCapture.CaptureToFile)
                encoder=QImageEncoderSettings()
                encoder.setCodec(extension)  #设置文件类型
                encoder.setQuality(QMultimedia.HighQuality)  #设置图像质量
                self.imageCapture.setEncodingSettings(encoder)  #设置图像编码的类型
                self.camera.start()
                self.camera.searchAndLock()
                self.imageCapture.capture(self.fileName)  #捕捉图像到文件
                self.camera.unlock()
    def btn_buffer_clicked(self):
        if self.imageCapture.isReadyForCapture():
            self.camera.setCaptureMode(QCamera.CaptureStillImage)  # 设置捕捉模式
            self.imageCapture.setCaptureDestination(QCameraImageCapture.CaptureToBuffer)
            self.imageCapture.setBufferFormat(QVideoFrame.Format_BGRA32)
            self.camera.searchAndLock()
            self.imageCapture.capture()  #捕捉图像到缓存
            self.camera.unlock()
    def image_captured(self,n,image):
        browser=image_browser(image,self)  #自定义对话框，用于预览图像
        browser.show()
if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
