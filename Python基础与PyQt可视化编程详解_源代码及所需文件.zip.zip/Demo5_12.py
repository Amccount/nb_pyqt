def var():   #Demo5_12.py
    global mess
    mess = "我是局部变量"
    print(mess,id(mess))
# 下面是主程序
mess = "我是全局变量"
var()
print(mess,id(mess))
#运行结果
#我是局部变量 1923199471888
#我是局部变量 1923199471888
