import sys  #Demo9_3.py
from PyQt5.QtWidgets import QApplication, QWidget, QLabel,QPushButton
from PyQt5.QtCore import Qt

class myWindow(QWidget):
    def __init__(self,parent=None,winType = Qt.Widget):
        super().__init__(parent,winType)
        self.setWindowTitle("欢迎来到我的世界")
        # add more...
class welcomeWindow(QWidget):
    def __init__(self,parent=None,winType = Qt.Widget):
        super().__init__(parent,winType)
        self.resize(300, 100)
        self.setupUi()
    def setupUi(self):
        label = QLabel("欢迎来到我的世界！")
        label.setParent(self)
        label.setGeometry(70, 30, 200, 30)
        font = label.font()
        font.setPointSize(15)
        label.setFont(font)
        btn = QPushButton("进入>>",self)
        btn.setGeometry(200,70,70,20)
        btn.clicked.connect(self.enter)  #信号与槽的连接
    def enter(self):
        self.win = myWindow(None,Qt.Window)
        self.win.show()  #显示另外一个窗口
        self.close()
if __name__ == '__main__':
    app=QApplication(sys.argv)
    welcome = welcomeWindow(None,Qt.SplashScreen)  #欢迎窗口
    welcome.show()
    n = app.exec()
    sys.exit(n)
