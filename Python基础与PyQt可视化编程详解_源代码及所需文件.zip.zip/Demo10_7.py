import sys  #Demo10_7.py
from PyQt5.QtWidgets import QApplication, QWidget,QPushButton,QHBoxLayout
from PyQt5.QtCore import Qt

class QmyWidget(QWidget):
    def __init__(self,parent = None):
        super().__init__(parent)
        self.ID_1 = self.startTimer(500,Qt.PreciseTimer)  #启动第1个计时器
        self.ID_2 = self.startTimer(1000,Qt.CoarseTimer)  #启动第2个计时器
        btn_1 = QPushButton("停止第1个计时器", self)
        btn_2 = QPushButton("停止第2个计时器", self)
        btn_1.clicked.connect(self.killTimer_1)
        btn_2.clicked.connect(self.killTimer_2)

        h=QHBoxLayout(self)
        h.addWidget(btn_1)
        h.addWidget(btn_2)
    def timerEvent(self, event):  #计时器事件
        print("我是第"+str(event.timerId())+"个计时器。")
    def killTimer_1(self):
        if self.ID_1:
            self.killTimer(self.ID_1)  #停止第1个计时器
    def killTimer_2(self):
        if self.ID_2:
            self.killTimer(self.ID_2)  #停止第2个计时器
if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = QmyWidget()
    myWindow.show()
    sys.exit(app.exec())
