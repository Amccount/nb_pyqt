from PyQt5.QtCore import QPoint,QPointF  #Demo8_3.py
p1 = QPoint(3,4)
p2 = QPoint(5,8)
p3 = p2-p1
p4 = p1*3
print(p3.x(), p3.y())
print(p4.x(),p4.y())
print(p1 == p2)
print(p1 != p2)
#运算结果：
#2 4
#9 12
#False
#True
