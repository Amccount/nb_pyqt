from openpyxl import load_workbook  #Demo6_27.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
wsheet["A8"] = "=SUM(C2:G6)"
wsheet["B8"] = "=MAX(D2:H6)"
wsheet["C8"] = "=AVERAGE(D2:H6)"
