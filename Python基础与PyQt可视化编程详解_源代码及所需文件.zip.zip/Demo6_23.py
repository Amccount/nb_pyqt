from openpyxl import load_workbook  #Demo6_23.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
rows = wsheet.iter_rows(min_row=2,max_row=6,min_col=2,max_col=6) #行排列的单元格元组
for row in rows:
    for cell in row:
        print(cell.value,end=' ')
    print("\n")
cols=wsheet.iter_cols(min_row=2,max_row=6,min_col=2,max_col=6,values_only=True) #输出值
for col in cols:
    for value in col:
        print(value,end=' ')
    print("\n")
row_all = wsheet.rows  #按行排列的所有单元格对象序列
col_all = wsheet.columns  #按列排列的所有单元格对象序列
for i in tuple(row_all): #用tuple函数将序列转成元组
    for j in i:
        print(j.value, end = " ")
    print("\n")
