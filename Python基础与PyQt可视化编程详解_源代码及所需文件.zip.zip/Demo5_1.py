def total(n) -> int:    #定义total()函数，提示返回整数   #Demo5_1.py
    """输入大于0的整数N，返回0+1+2+3+…+N的值"""
    if n>0:
        y =0
        for i in range(1,n+1):
            y = y+i
        return y

x = input("请输入一个大于1的整数：")
x = int(x)   #将字符串转换成整数
xx = total(x)  #调用自定义函数total()
print("从0到{}的和是：{}".format(x,xx))
