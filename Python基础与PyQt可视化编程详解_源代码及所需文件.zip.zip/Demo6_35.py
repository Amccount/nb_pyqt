from openpyxl import Workbook  #Demo6_35.py
from openpyxl.chart import Reference,SurfaceChart, SurfaceChart3D
wbook = Workbook()
wsheet = wbook.active
DOE = [ ["V1_V2", 20, 40, 60, 80, 100,],  #数据第1列和第1行是变量的取值
        [10, 25, 20, 15, 26, 24],
        [20, 15, 15, 10, 15, 25],
        [30, 19, 18, 12, 16, 28],
        [40, 23, 25, 15, 25, 35],
        [50, 25, 15, 12, 12, 18],
        [60, 30, 10, 11, 19, 22],
        [70, 35, 15, 15, 21, 25],
        [80, 40, 35, 25, 27, 27],
        [90, 48, 38, 28, 35, 35],
        [100, 55, 42, 35, 42,45]  ]
for row in DOE:
    wsheet.append(row)

surface1 = SurfaceChart()
surface2 = SurfaceChart()
surface3D1 = SurfaceChart3D()
surface3D2 = SurfaceChart3D()
surface2.wireframe = True    #设置成线架状态
surface3D2.wireframe = True  #设置成线架状态
surface1.title = "2D Contour"
surface2.title = "2D wireframe"
surface3D1.title = "3D Contour"
surface3D2.title = "3D wireframe"

variable = Reference(wsheet, min_col=1, min_row=2, max_row=11)
DOE_data = Reference(wsheet, min_col=2, max_col=6, min_row=1, max_row=11)

surface1.add_data(DOE_data, titles_from_data=True)
surface2.add_data(DOE_data, titles_from_data=True)
surface3D1.add_data(DOE_data, titles_from_data=True)
surface3D2.add_data(DOE_data, titles_from_data=True)

surface1.set_categories(variable)
surface2.set_categories(variable)
surface3D1.set_categories(variable)
surface3D2.set_categories(variable)

wsheet.add_chart(surface1, "A20")
wsheet.add_chart(surface2, "J20")
wsheet.add_chart(surface3D1, "A40")
wsheet.add_chart(surface3D2, "J40")
wbook.save("d:\\python\\surface.xlsx")
