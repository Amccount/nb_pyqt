import sys  #Demo7_4.py
from PyQt5.QtWidgets import QApplication,QWidget,QLabel,QPushButton

class QmyUi():  #定义QmyUi类
    def setupUi(self,window):  # 定义方法，形参window是一个窗口实例
        window.setWindowTitle('Hello')
        window.resize(300, 150)

        self.label = QLabel(window)  # 在窗口上创建标签
        self.label.setText('欢迎使用本书学习编程！')
        self.label.setGeometry(80, 50, 150, 20)

        self.button = QPushButton(window)  # 在窗口上创建按钮
        self.button.setText("关 闭")
        self.button.setGeometry(120, 100, 50, 20)

if __name__ == '__main__':
    app = QApplication(sys.argv)
    myWindow = QWidget()

    ui = QmyUi()  #用QmyUi类创建实例ui
    ui.setupUi(myWindow)  #调用ui的方法setupUi()，并以窗口实例作为实参
    ui.button.setText("Close")  #重新设置按钮的显示文字
    ui.button.clicked.connect(myWindow.close)  #窗口上的按钮事件与窗口事件关联

    myWindow.show()
    n = app.exec()
    sys.exit(n)
