def trapezoid (side1,side2,height):   #Demo5_5.py
    """形参顺序是side1,side2,height"""
    area=(side1+side2)*height/2
    return area

s1 = input("输入梯形上底长度：")
s2 = input("输入梯形下底长度：")
h  = input("输入梯形高度：")
s1 = float(s1)   #将字符串转换成浮点数
s2 = float(s2)   #将字符串转换成浮点数
h  = float(h)   #将字符串转换成浮点数

ss = trapezoid (height = h,side1 = s1,side2 =s2)  #用形参名字做关键字，顺序可以打乱
print("梯形的面积是",ss)
