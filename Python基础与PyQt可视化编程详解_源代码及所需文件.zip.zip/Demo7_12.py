import sys  #Demo7_12.py
from PyQt5.QtWidgets import QApplication, QWidget

import student  #导入student.py文件

class QmyWidget(QWidget):  #创建QmyWindget类，父类是QWidget
    def __init__(self,parent = None):
        super().__init__(parent)  #初始化父类QWidget，这时self是QWidget的窗口对象
        self.ui = student.Ui_Form()  #实例化student.py文件中的Ui_Form类
        self.ui.setupUi(self)  #调用Ui_Form类的函数setupUi()，并以self为实参传递给形参Form

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = QmyWidget()  #用QmyWidget()类实例化对象myWindow，myWindow是窗口
    myWindow.show()
    n = app.exec()
    sys.exit(n)
