from openpyxl import Workbook  #Demo6_31.py
from openpyxl.chart import Reference,AreaChart,AreaChart3D,legend
wbook = Workbook()
wsheet = wbook.active
score =   [ ['日期', '一班', '二班'],     #数据
          ["星期一", 90.2, 96],
          ["星期二", 95, 89.8],
          ["星期三", 89, 93.2],
          ["星期四", 94.6, 92],
          ["星期五", 89.8, 88]  ]
for item in score:
    wsheet.append(item)
area = AreaChart()   #创建面积图对象
area3D = AreaChart3D()  #创建三维面积图对象

area.title = "Area Chart"    #设置名称
area3D.title = "Area3D Chart"   #设置名称
area.style = area3D.style  = 15   #设置样式
area.x_axis.title = area3D.x_axis.title='日期'  #设置x轴名称
area.y_axis.title = area3D.y_axis.title='出勤率' #设置y轴名称
area.legend = area3D.legend = legend.Legend(legendPos='tr') #设置图例位置

xLabel = Reference(wsheet,min_col=1,min_row=2,max_row=6)  #设置x轴坐标数据
yData = Reference(wsheet,min_col=2,max_col=3,min_row=1,max_row=6)  #设置y轴数据
area.add_data(yData,titles_from_data=True)    #添加y轴数据，数据名称来自数据的第1个值
area3D.add_data(yData,titles_from_data=True)  #添加y轴数据，数据名称来自数据的第1个值

area.set_categories(xLabel)    #添加x轴数据
area3D.set_categories(xLabel)   #设置x轴数据

area.width=area3D.width = 13   #设置高度
area.height=area3D.height = 8  #设置宽度

wsheet.add_chart(area,"A10")   #二维面积图添加进工作表格中，左上角在A10单元格处
wsheet.add_chart(area3D,"J10")   #三维面积图添加进工作表格中，左上角在J10处

wbook.save("d:\\python\\area.xlsx")
