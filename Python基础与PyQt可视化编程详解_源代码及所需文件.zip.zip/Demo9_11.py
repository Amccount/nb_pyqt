import sys  #Demo9_11.py
from PyQt5.QtWidgets import (QApplication,QDialog,QWidget,QPushButton,QLineEdit,QMenuBar,
                    QTextBrowser,QVBoxLayout,QHBoxLayout,QFormLayout,QFileDialog)
from dialog import myDialog

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle("学生成绩输入系统")
        self.widget_setupUi()
        self.dialog = myDialog(self)
        self.dialog.finished.connect(self.dialog_finished)

    def widget_setupUi(self):  #建立主程序界面
        menuBar = QMenuBar(self)  #定义菜单栏
        file_menu = menuBar.addMenu("文件(&F)")  #定义菜单
        action_input = file_menu.addAction("输入成绩(&I)")  #添加动作
        action_save = file_menu.addAction("保存(&S)")  #添加动作
        file_menu.addSeparator()
        action_exit = file_menu.addAction("退出(&E)")  #添加动作
        self.textBrowser = QTextBrowser(self)  #显示数据控件
        v= QVBoxLayout(self)  #主程序界面的布局
        v.addWidget(menuBar)
        v.addWidget(self.textBrowser)

        action_input.triggered.connect(self.action_input_triggered) #输入成绩动作的信号与槽的连接
        action_save.triggered.connect(self.action_save_triggered)  #保存动作的信号与槽的连接
        action_exit.triggered.connect(self.close)  #退出动作的信号与窗口关闭的连接

    def action_input_triggered(self):  #自定义槽函数
        self.dialog.open()
    def action_save_triggered(self):  #自定义槽函数
        string = self.textBrowser.toPlainText()
        print(string)
        if len(string) > 0:
            filename, filter = QFileDialog.getSaveFileName(self, "保存文件",
                                         "d:\\", "文本文件(*.txt)")
            if len(filename) > 0:
                print(filename)
                fp = open(filename, "a+", encoding="UTF-8")
                fp.writelines(string)
                fp.close()
    def dialog_finished(self,value):   #自定义槽函数，应用按钮
        template="姓名：{}  学号：{}  语文：{}  数学：{}  英语：{}"
        if value == 1 or value == 2:
            string = template.format(self.dialog.line_name.text(),self.dialog.line_number.text(),
             self.dialog.line_chinese.text(),self.dialog.line_math.text(),self.dialog.line_english.text())
            self.textBrowser.append(string)
            self.dialog.line_name.clear()
            self.dialog.line_number.clear()
            self.dialog.line_chinese.clear()
            self.dialog.line_math.clear()
            self.dialog.line_english.clear()
            if value == 2:
                self.dialog.open()
                self.dialog.move(self.dialog.postion)
            else:
                self.dialog.close()
    def btn_ok_clicked(self):   #自定义槽函数，单击“确定”按钮
        self.btn_apply_clicked()
        self.dialog.close()
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
