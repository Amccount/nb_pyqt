from openpyxl import Workbook  #Demo6_32.py
from openpyxl.chart import Reference,BarChart,BarChart3D
wbook = Workbook()
wsheet = wbook.active
score = [['日期', '一班', '二班'],["星期一", 90.2, 96],["星期二", 95, 89.8],
         ["星期三", 89, 93.2],["星期四", 94.6, 92],["星期五", 89.8, 88]]
for item in score:
    wsheet.append(item)
bar1 = BarChart()   #创建条形图对象
bar2 = BarChart()   #创建条形图对象
bar3D = BarChart3D()  #创建条形图对象
col1 = BarChart()   #创建条形图对象
col2 = BarChart()   #创建条形图对象
col3D = BarChart3D() #创建条形图对象
bar1.type = bar2.type = bar3D.type = 'bar'
col1.type = col2.type = col3D.type = 'col'
bar2.overlap = col2.overlap = 100

bar1.title = bar2.title = bar3D.title = "水平 Bar Chart"    #设置名称
col1.title = col2.title = col3D.title = "竖直 Bar Chart"   #设置名称

bar1.style=bar2.style=bar3D.style=col1.style=col2.style=col3D.style= 15   #设置样式
bar1.x_axis.title=bar2.x_axis.title=col1.x_axis.title=col2.x_axis.title='日期' #x轴名称
bar3D.x_axis.title=col3D.x_axis.title='日期'
bar1.y_axis.title=bar2.y_axis.title=col1.y_axis.title=col2.y_axis.title='出勤率' #y轴名称
bar3D.y_axis.title=col3D.y_axis.title='出勤率'

xLabel = Reference(wsheet,min_col=1,min_row=2,max_row=6)  #设置x轴坐标数据
yData = Reference(wsheet,min_col=2,max_col=3,min_row=1,max_row=6)  #设置y轴数据

bar1.add_data(yData,titles_from_data=True)  #添加y轴数据，数据名称来自数据的第1个值
bar2.add_data(yData,titles_from_data=True)  #添加y轴数据，数据名称来自数据的第1个值
bar3D.add_data(yData,titles_from_data=True) #添加y轴数据，数据名称来自数据的第1个值
col1.add_data(yData,titles_from_data=True)  #添加y轴数据，数据名称来自数据的第1个值
col2.add_data(yData,titles_from_data=True)  #添加y轴数据，数据名称来自数据的第1个值
col3D.add_data(yData,titles_from_data=True) #添加y轴数据，数据名称来自数据的第1个值

col3D.series[0].shape = 'pyramid'   #设置形状
col3D.series[1].shape = 'cylinder'   #设置形状

bar1.set_categories(xLabel)   #添加x轴数据
bar2.set_categories(xLabel)   #添加x轴数据
bar3D.set_categories(xLabel)  #添加x轴数据
col1.set_categories(xLabel)   #添加x轴数据
col2.set_categories(xLabel)   #添加x轴数据
col3D.set_categories(xLabel)  #添加x轴数据

bar1.width=bar2.width=bar3D.width=col1.width=col2.width=col3D.width=13   #设置高度
bar1.height=bar2.height=bar3D.height=col1.height=col2.height=col3D.height=8  #设置宽度

wsheet.add_chart(bar1,"A10")   #图表添加进工作表格中
wsheet.add_chart(bar2,"H10")   #图表添加进工作表格中
wsheet.add_chart(bar3D,"P10")  #图表添加进工作表格中
wsheet.add_chart(col1,"A30")   #图表添加进工作表格中
wsheet.add_chart(col2,"H30")   #图表添加进工作表格中
wsheet.add_chart(col3D,"P30")  #图表添加进工作表格中
wbook.save(filename="d:\\python\\bar.xlsx")
