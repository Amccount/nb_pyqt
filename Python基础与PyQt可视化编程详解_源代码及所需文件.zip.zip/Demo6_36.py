from openpyxl import Workbook  #Demo6_36.py
from openpyxl.chart import RadarChart,Reference
wbook = Workbook()
wsheet = wbook.active

data = [['years', "Job", "Rock", "Robot", "White"],
        [2013, 905, 150, 251],
        [2014, 0, 653, 201, 410],
        [2015, 0, 330, 552, 353],
        [2016, 0, 0, 740, 120],
        [2017, 0, 0, 830, 90],
        [2018, 150, 0, 710, 51],
        [2019, 500, 0, 302, 230],
        [2020, 810, 0, 220, 640],
        [2021, 330, 0, 54, 555],
        [2022, 55, 0, 15, 315 ] ]
for row in data:
    wsheet.append(row)

radar1 = RadarChart()
radar2 = RadarChart()
radar2.type = "filled"  #设置线架模式
radar1.title = "标准图"
radar2.title = "填充图"
rLabel = Reference(wsheet, min_col=1, min_row=2, max_row=13)
rData = Reference(wsheet, min_col=2, max_col=5, min_row=1, max_row=13)
radar1.add_data(rData, titles_from_data=True)
radar2.add_data(rData, titles_from_data=True)
radar1.set_categories(rLabel)
radar2.set_categories(rLabel)

radar1.y_axis.delete = True
radar2.y_axis.delete = True

wsheet.add_chart(radar1, "A20")
wsheet.add_chart(radar2, "J20")

wbook.save("d:\\python\\radar.xlsx")
