def N_her(n):   #Demo5_14.py
    '''计算n阶阶乘 n!'''
    if n==1:
        return 1 # 明确的结束条件
    n = n*N_her(n-1) # 递归调用，计算n! = n*(n-1)!
    return n
def total(n):
    total=0
    for i in range(1,n+1):
        total = total+N_her(i)  #在函数中调用其他函数
    return total

n = input("请输入正整数n:")
n = int(n)    #字符串转换成整数
print("1！+2！+3！+...+n!=",total(n))
#运行结果
#请输入正整数n:10
#1！+2！+3！+...+n!= 4037913
