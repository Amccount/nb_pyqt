from openpyxl import load_workbook  #Demo6_26.py
wbook = load_workbook("d:\\python\\student.xlsx")
wsheet = wbook['学生成绩']
wsheet.merge_cells("A1:B2")
wsheet.merge_cells(start_row=3,end_row=5,start_column=3,end_column=6)
wsheet.unmerge_cells("A1:B2")
wsheet.unmerge_cells(start_row=3,end_row=5,start_column=3,end_column=6)
