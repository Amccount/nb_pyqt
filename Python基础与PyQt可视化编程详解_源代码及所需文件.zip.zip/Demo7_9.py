import sys  #Demo7_9.py
from PyQt5.QtWidgets import  QApplication, QWidget

from myUi import QmyUi  #从myUi.py文件中导入QmyUi类

class QmyWidget(QWidget,QmyUi): #创建QmyWindget类，父类是QWidget和QmyUi
    def __init__(self,parent = None):
        super().__init__(parent)  #初始化父类QWidget，self是QWidget的一个窗口对象
        self.setupUi(self)  #调用QmyUi的函数setupUi()，并以self为实参传递给形参window
        self.button.setText("Close")  # 重新设置按钮的显示文字
        self.button.clicked.connect(self.close)  # 窗口上的按钮事件与窗口事件关联

if __name__ == "__main__":
    app = QApplication(sys.argv)
    myWindow = QmyWidget() #用QmyWidget()类实例化对象myWindow，myWindow是窗口
    myWindow.show()
    n = app.exec()
    sys.exit(n)
