import sys,math   #Demo12_1.py
from PyQt5.QtWidgets import QApplication,QWidget
from PyQt5.QtGui import QPen,QPainter
from PyQt5.QtCore import QPointF

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(600,500)
    def paintEvent(self,event):
        painter=QPainter(self)
        font=painter.font()
        font.setPixelSize(20)
        painter.setFont(font)  #设置字体

        pen=QPen()   #钢笔
        pen.setWidth(2)  #线条宽度
        painter.setPen(pen)  #设置钢笔
        r=100   #五角星的外接圆的半径
        x=self.width()/2
        y=self.height()/2
        p1 = QPointF(r * math.cos(-90 * math.pi / 180) + x, r * math.sin(-90 * math.pi / 180) + y)
        p2 = QPointF(r * math.cos(-18 * math.pi / 180)+x, r * math.sin(-18 * math.pi / 180)+y)
        p3 = QPointF(r * math.cos(54 * math.pi / 180)+x, r * math.sin(54 * math.pi / 180)+y)
        p4 = QPointF(r * math.cos(126 * math.pi / 180)+x, r * math.sin(126 * math.pi / 180)+y)
        p5 = QPointF(r * math.cos(198 * math.pi / 180)+x, r * math.sin(198 * math.pi / 180)+y)

        painter.drawPolyline(p1,p3,p5,p2,p4,p1)  #绘制折线
        painter.drawText(p1,"  p1")  #绘制文字
        painter.drawText(p2, "  p2")
        painter.drawText(p3, "  p3")
        painter.drawText(p4, "  p4")
        painter.drawText(p5, "  p5")
        super().paintEvent(event)
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
