# student.py   #Demo5_30.py
def total(*arg):
    SUM = 0
    for i in arg:
        SUM = SUM+i
    return SUM
def average(*arg):
    n=len(arg)
    return total(*arg)/n
class st(object):
    def __init__(self,name=None,number=None,score=None):
        self.name=name
        self.number=number
        self.score=score
