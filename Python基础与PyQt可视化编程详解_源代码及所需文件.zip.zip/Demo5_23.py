class student(object):   #Demo5_23.py
    def __init__(self,name=None,score=None):
        self.__name = name     # 私有属性
        self.__score = score     # 私有属性

    def _setName(self,name):   # 受保护的方法
        self.__name = name
    def _getName(self):        # 受保护的方法
        return self.__name
    def _setScore(self,score):   # 受保护的方法
        self.__score = score
    def _getScore(self):       # 受保护的方法
        return self.__score

liming  = student()
liming._setName("李明")
liming._setScore(98)
print("{}的成绩是{}".format(liming._getName(),liming._getScore()))
#运行结果
#李明的成绩是98
