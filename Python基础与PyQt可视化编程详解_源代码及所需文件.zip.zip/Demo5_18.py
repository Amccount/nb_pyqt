class person(object):   #Demo5_18.py
    nation = "汉族"  #类属性
    party = "群众"   #类属性
    def __init__(self,p_name,p_age):
        self.name = p_name   #实例属性
        self.age = p_age     #实例属性
        self.i = 0
    def output(self):
        self.i = self.i+1
        print("第{}次输出：{} {}".format(self.i,self.name,self.age))  #输出实例属性name和age
    def xx(self):
        self.i = self.i+1
        person.nation = "维吾尔族"
        print("第{}次输出：{} {}".format(self.i,self.nation,person.nation)) #输出实例类变量和类变量
student = person(p_name = "李明",p_age = 15)  #用类person创建实例strudent
teacher = person(p_name = "王芳",p_age = 33)  #用类person创建实例teacher


print("student第1次输出",student.nation,student.party)  #第1次输出类属性
print("teacher第1次输出",teacher.nation,teacher.party)   #第1次输出类属性

person.nation = "满族"  #修改类属性
person.party = "团员"   #修改类属性
print("student第2次输出",student.nation,student.party)  #第2次输出类属性
print("teacher第2次输出",teacher.nation,teacher.party)   #第2次输出类属性

student.nation = "苗族"
student.party = "党员"
print("student第3次输出",student.nation,student.party)  #第3次输出类属性
print("teacher第3次输出",teacher.nation,teacher.party)   #第3次输出类属性

print("person输出",person.nation,person.party)   #输出类属性(改变实例的类属性后)

teacher.xx()
student.xx()
#运行结果
#student第1次输出 汉族 群众
#teacher第1次输出 汉族 群众
#student第2次输出 满族 团员
#teacher第2次输出 满族 团员
#student第3次输出 苗族 党员
#teacher第3次输出 满族 团员
#person输出 满族 团员
#第1次输出：维吾尔族 维吾尔族
#第1次输出：苗族 维吾尔族
