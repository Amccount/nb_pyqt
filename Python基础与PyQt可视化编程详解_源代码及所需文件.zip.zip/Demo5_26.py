class person:   #Demo5_26.py
    def __init__(self,name=None,address=None):
        self.name = name
        self.address = address  #需要删除的属性
    def setName(self,name):    #需要重写的方法
        self.name = name
class student(person):
    def __init__(self,number = None,score = None):
        super().__init__()
        self.number = number
        self.score = score
        del self.address       #删除父类的属性
    def setNumber(self):
        self.number = input("请输入学号：")
    def setScore(self):
        self.score = input("请输入成绩：")
    def setName(self):        #重写父类的函数
        self.name = input("请输出学生姓名：")

liming = student()
liming.setName()   #调用子类的setName()方法
liming.setNumber()
liming.setScore()
print("姓名：{} 学号：{} 成绩：{}".format(liming.name,liming.number,liming.score))

#运行结果
#请输出学生姓名：李明
#请输入学号：20201
#请输入成绩：96
#姓名：李明 学号：20201 成绩：96
