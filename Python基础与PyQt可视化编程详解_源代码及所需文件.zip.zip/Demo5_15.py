class car:   #Demo5_15.py
    """汽车模板"""
    def __init__(self,name,color,length,width,height,power):
        self.name  = name     #用变量定义品牌属性
        self.color   = color    #用变量定义颜色属性
        self.length  = length   #用变量定义长度属性
        self.width   = width    #用变量定义宽带属性
        self.height  = height   #用变量定义高度属性
        self.power  = power    #用变量定义功率属性
    def start(self):      # 定义汽车的启动功能
        pass    # 需进一步编程
    def accelerate(self): # 定义汽车的加速功能
        pass    # 需进一步编程
    def brake(self):      # 定义汽车的制动功能
        pass    # 需进一步编程

jietuCar   = car("chery","black",2800,1800,1600,5000)  # 定义第一辆汽车并赋予属性
xingyueCar = car("geely","red",2900,1750,1610,5200)   # 定义第二辆汽车并赋予属性
