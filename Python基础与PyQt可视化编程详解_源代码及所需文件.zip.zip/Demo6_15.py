import openpyxl   #导入openpyxl包   #Demo6_15.py
file = "d:\\python\\student.xlsx"  #打开文件路径
st_book = openpyxl.load_workbook(file)  #用openpyxl的load_workbook()方法打开文件
st_sheet = st_book["学生成绩"]  #引用名称为"学生成绩"的工作表格
t1 = st_sheet["C2"].value+st_sheet["D2"].value+st_sheet["E2"].value+st_sheet["F2"].value
t2 = st_sheet["C3"].value+st_sheet["D3"].value+st_sheet["E3"].value+st_sheet["F3"].value
t3 = st_sheet["C4"].value+st_sheet["D4"].value+st_sheet["E4"].value+st_sheet["F4"].value
t4 = st_sheet["C5"].value+st_sheet["D5"].value+st_sheet["E5"].value+st_sheet["F5"].value
t5 = st_sheet["C6"].value+st_sheet["D6"].value+st_sheet["E6"].value+st_sheet["F6"].value
st_sheet["G1"],st_sheet["H1"] = "总分","平均分"
st_sheet["G2"],st_sheet["H2"] = t1,t1/4
st_sheet["G3"],st_sheet["H3"] = t2,t2/4
st_sheet["G4"],st_sheet["H4"] = t3,t3/4
st_sheet["G5"],st_sheet["H5"] = t4,t4/4
st_sheet["G6"],st_sheet["H6"] = t5,t5/4
st_book.save(file)
