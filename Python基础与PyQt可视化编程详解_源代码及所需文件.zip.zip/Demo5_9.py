def person(name, *primary, **feature):  # Demo5_9.py
    person_name = name
    height = None
    weight = None
    sex = None
    age = None
    job = None

    if len(primary) == 1:
        height = primary[0]
    if len(primary) == 2:
        height = primary[0]
        weight = primary[1]
    if "sex" in feature: sex = feature["sex"]
    if "age" in feature: age = feature["age"]
    if "job" in feature: job = feature["job"]

    print("{}的身高{},体重{},性别{},年龄{},工作{}".format(name, height, weight, sex, age, job))


person("Robot", 177, sex=True, weight=78)
person("Robot", 177, 38, sex=True, weight=78, job="writer")
# 运行结果
# Robot的身高177,体重None,性别True,年龄None,工作None
# Robot的身高177,体重38,性别True,年龄None,工作writer
