import sys   #Demo12_8.py
from PyQt5.QtWidgets import QApplication,QWidget
from PyQt5.QtGui import QPainter

class myWindow(QWidget):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.resize(600,500)
    def paintEvent(self,event):
        painter=QPainter(self)
        painter.setViewport(100,100,300,200)  #视口
        painter.setWindow(-50,-50,100,100)  #窗口
        painter.drawRect(0, 0, 50, 50)  #绘制矩形
        for i in range(18):
            painter.drawEllipse(0,0,50,50)  #绘制椭圆
            painter.rotate(20)  #旋转坐标系
if __name__ == '__main__':
    app=QApplication(sys.argv)
    window = myWindow()
    window.show()
    sys.exit(app.exec())
